﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * main.cpp
 * Copyright (c) 2010 itsnotabigtruck.
 * No rights reserved.
 * 
 * All rights are waived to the maximum extent possible; see
 * http://creativecommons.org/publicdomain/zero/1.0/ for more information
 *
 * Replace this banner when writing your own applications
 */

#include <windows.h>
#include <zdk.h>

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nShowCmd)
{
    MessageBox(NULL, L"HACK THE PLANET!", L"Hackage has occurred", MB_OK);
    return 0;
}
