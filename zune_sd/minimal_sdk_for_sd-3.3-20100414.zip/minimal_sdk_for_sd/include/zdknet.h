﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zdknet.h => zdknet.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZDKNET_H
#define _ZDKNET_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: (none)
 *****************************************************************************/

/* Zune-to-Zune connectivity */

/* ZDKNet_AbortSearch */
/* ZDKNet_DoWork */
/* ZDKNet_DropPlayer */
/* ZDKNet_EndGame */
/* ZDKNet_GetCallbackInterface */
/* ZDKNet_GetGameProperty */
/* ZDKNet_GetHostPlayer */
/* ZDKNet_GetLastStateResult */
/* ZDKNet_GetLocalPlayer */
/* ZDKNet_GetNetworkStats */
/* ZDKNet_GetParam */
/* ZDKNet_GetPlayerBySlot */
/* ZDKNet_GetPlayerCount */
/* ZDKNet_GetPlayerSlots */
/* ZDKNet_GetQueuedPayloadCount */
/* ZDKNet_GetSearchResult */
/* ZDKNet_GetSearchResultsCount */
/* ZDKNet_GetSessionState */
/* ZDKNet_GetSessionType */
/* ZDKNet_HostGame */
/* ZDKNet_Initialize */
/* ZDKNet_IsEveryoneReady */
/* ZDKNet_IsHost */
/* ZDKNet_IsSearchComplete */
/* ZDKNet_JoinGame */
/* ZDKNet_JoinGameFromInvite */
/* ZDKNet_LeaveGame */
/* ZDKNet_RequestLocalPlayerReady */
/* ZDKNet_ResetReady */
/* ZDKNet_SearchForGames */
/* ZDKNet_SendDataToAll */
/* ZDKNet_SendDataToPlayer */
/* ZDKNet_SetCallbackInterface */
/* ZDKNet_SetGameProperty */
/* ZDKNet_SetParam */
/* ZDKNet_SetPlayerSlots */
/* ZDKNet_SetSessionType */
/* ZDKNet_Shutdown */
/* ZDKNet_StartGame */

#ifdef __cplusplus
}
#endif
#endif
