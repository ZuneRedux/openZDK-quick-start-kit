﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zam.h => zam.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZAM_H
#define _ZAM_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck
 *****************************************************************************/

#ifdef ZUNE_SD
typedef struct
{
    int X;
    int Y;
    int Unknown1;
    int Unknown2;
} ZAM_TOUCH_POSITION;

HRESULT WINAPI ZAMGetAppID(DWORD *appID);
HRESULT WINAPI ZAMGetAppFlags(DWORD *flags);
HRESULT WINAPI ZAMGetInputNotificationHandle(HANDLE *handle);
HRESULT WINAPI ZAMGetOutputDisplayType(DWORD *type);
HRESULT WINAPI ZAMGetTouchPosition(ZAM_TOUCH_POSITION *position);
HRESULT WINAPI ZAMGetTvType(DWORD *type);
HRESULT WINAPI ZAMGetVolume(DWORD *volume);
HRESULT WINAPI ZAMLaunchApp(DWORD appId, LPCWSTR cmdLine, DWORD arg3);
HRESULT WINAPI ZAMNudgeVolume(DWORD change);
HRESULT WINAPI ZAMPrepareStorage();
HRESULT WINAPI ZAMQueryFeatureParameter(DWORD feature, DWORD *value);
HRESULT WINAPI ZAMRestartApp();
HRESULT WINAPI ZAMSetOutputDisplayType(DWORD type);
HRESULT WINAPI ZAMSetTvType(DWORD type);
HRESULT WINAPI ZAMSetWifi(BOOL enabled);
HRESULT WINAPI ZAMSignalUserActivity(BOOL flag);
HRESULT WINAPI ZAMSuspendDevice();
HRESULT WINAPI ZAM_XnaDbg_CloseSession();
HRESULT WINAPI ZAM_XnaDbg_CreateSession();
BOOL WINAPI ZAM_XnaDbg_IsInSession();
/* ZAMEnqueueZInput */
/* ZAMGetAsyncKeyState */
/* ZAMGetInputNotification */
/* ZAMGetPowerTimeout */
/* ZAMKillIdleTimer */
/* ZAMProcessGestureSetting */
/* ZAMSendInput */
/* ZAMSetIdleTimer */
/* ZAMSetPowerTimeout */
/* ZAMSetScaledVolume */
/* ZAMStopApp */
/* ZAM_XnaDbg_PopFromInputQueue */
/* ZAM_XnaDbg_PopFromOutputQueue */
/* ZAM_XnaDbg_PushToInputQueue */
/* ZAM_XnaDbg_PushToOutputQueue */
/* ZAM_XnaDbg_SetSessionState */
/* ZAMGetAsyncKeyState */
#endif

#ifdef __cplusplus
}
#endif
#endif
