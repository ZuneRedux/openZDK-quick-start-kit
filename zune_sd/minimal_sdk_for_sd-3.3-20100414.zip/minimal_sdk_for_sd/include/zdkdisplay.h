﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zdkdisplay.h => zdksystem.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZDKDISPLAY_H
#define _ZDKDISPLAY_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck
 *****************************************************************************/

/* Common types */

typedef float ZDK_MATRIX[4][4];

typedef struct
{
    int Left;
    int Top;
    int Right;
    int Bottom;
} ZDK_RECT;

/* 2D initialization */

HRESULT WINAPI ZDKDisplay_Initialize();
HRESULT WINAPI ZDKDisplay_Cleanup();

/* System information */

HRESULT WINAPI ZDKDisplay_GetInfo(DWORD *screenWidth, DWORD *screenHeight);

/* Texture management */

DECLARE_HANDLE(HTEXTURE);

typedef enum
{
    TEXTURE_LOCK_DEFAULT         = 0x0,
    TEXTURE_LOCK_READONLY        = 0x10,
    TEXTURE_LOCK_NOSYSLOCK       = 0x800,  /* questionable */
    TEXTURE_LOCK_NOOVERWRITE     = 0x1000, /* questionable */
    TEXTURE_LOCK_DISCARD         = 0x2000,
    TEXTURE_LOCK_NO_DIRTY_UPDATE = 0x8000  /* questionable */
} ZDK_TEXTURE_LOCK_FLAGS;

typedef struct
{
    int Pitch;
    DWORD *Buffer;
} ZDK_TEXTURE_LOCK_INFO;

HRESULT WINAPI ZDKDisplay_CreateTexture(DWORD width, DWORD height, HTEXTURE *texture);
HRESULT WINAPI ZDKDisplay_FreeTexture(HTEXTURE texture);
HRESULT WINAPI ZDKDisplay_GetTextureData(HTEXTURE texture, ZDK_RECT *rect, void *buffer, DWORD dataSize);
HRESULT WINAPI ZDKDisplay_GetTextureInfo(HTEXTURE texture, DWORD *width, DWORD *height);
HRESULT WINAPI ZDKDisplay_SetTextureData(HTEXTURE texture, ZDK_RECT *rect, void *buffer, DWORD dataSize);
HRESULT WINAPI ZDKDisplay_TextureLockRect(HTEXTURE texture, ZDK_TEXTURE_LOCK_INFO *info, ZDK_RECT *rect, ZDK_TEXTURE_LOCK_FLAGS flags);
HRESULT WINAPI ZDKDisplay_TextureUnlockRect(HTEXTURE texture);

/* 2D rendering */

typedef enum
{
    BLEND_MODE_NONE,
    BLEND_MODE_ALPHA_BLEND,
    BLEND_MODE_ADDITIVE
} ZDK_BLEND_MODE;

typedef struct
{
    float X;
    float Y;
    float U;
    float V;
} ZDK_VERTEXDATA;

typedef struct
{
    ZDK_VERTEXDATA Vertices[4];
    DWORD Color;
} ZDK_SPRITE;

HRESULT WINAPI ZDKDisplay_BeginScene();
HRESULT WINAPI ZDKDisplay_Clear(DWORD color);
HRESULT WINAPI ZDKDisplay_DrawSprites(ZDK_SPRITE *sprites, DWORD spriteCount);
HRESULT WINAPI ZDKDisplay_EndScene();
HRESULT WINAPI ZDKDisplay_Present();
HRESULT WINAPI ZDKDisplay_ResolveBackBuffer(HTEXTURE texture);
HRESULT WINAPI ZDKDisplay_SetBlendMode(ZDK_BLEND_MODE blendMode);
HRESULT WINAPI ZDKDisplay_SetClipRect(ZDK_RECT *rect);
HRESULT WINAPI ZDKDisplay_SetRenderTarget(HTEXTURE texture);
HRESULT WINAPI ZDKDisplay_SetTexture(HTEXTURE texture);
HRESULT WINAPI ZDKDisplay_SetTransform(ZDK_MATRIX *matrix);
/* ZDKDisplay_SetTextureFilter */

#ifdef __cplusplus
}
#endif
#endif
