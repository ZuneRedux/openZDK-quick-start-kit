﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * compclient.h => compclient.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _COMPCLIENT_H
#define _COMPCLIENT_H
#ifdef __cplusplus
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif
#ifdef ZUNE_HD
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <windows.h>

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck, Netrix
 *****************************************************************************/

enum WindowOp
{
};

HRESULT WINAPI CompDisplay_Show(int);
HRESULT WINAPI CompDisplay_Snapshot(const RECT *, int, void *, unsigned int);
HRESULT WINAPI CompWindow_AlphaBlend(HWND, int);
HRESULT WINAPI CompWindow_BeginAnimation(HWND);
HRESULT WINAPI CompWindow_ChangeZOrder(HWND, int);
HRESULT WINAPI CompWindow_Close(HWND);
HRESULT WINAPI CompWindow_EndAndRunAnimation(HWND);
HRESULT WINAPI CompWindow_EndAndSetAnimation(HWND, WindowOp);
HRESULT WINAPI CompWindow_Hide(HWND);
HRESULT WINAPI CompWindow_SetOpacity(HWND, float, float);
HRESULT WINAPI CompWindow_SetPosition(HWND, float, float, float);
HRESULT WINAPI CompWindow_SetRotation(HWND, float, float);
HRESULT WINAPI CompWindow_SetScale(HWND, float, float, float);
HRESULT WINAPI CompWindow_SetUnitOrigin(HWND, float, float, float);
HRESULT WINAPI CompWindow_Show(HWND);

#endif
#endif
#endif
