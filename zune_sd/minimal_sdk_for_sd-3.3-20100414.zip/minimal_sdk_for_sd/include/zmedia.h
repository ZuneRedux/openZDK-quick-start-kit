﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zmedia.h => zmedia.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZMEDIA_H
#define _ZMEDIA_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck
 *****************************************************************************/

/* Error codes */

#define ZERROR_E_INSUFFICIENT_BUFFER                        HRESULT_FROM_WIN32(ERROR_INSUFFICIENT_BUFFER)
#define ZERROR_E_NOTINITIALIZED                             0x803A0000
#define ZERROR_E_NOTFOUND                                   0x803A0002
#define ZERROR_E_NOTOPEN                                    0x803A0003
#define ZERROR_E_OUTOFDATE                                  0x803A0006
#define ZERROR_E_DRMLICENSEEXPIRED                          0x803A0008
#define ZERROR_E_UNSUPPORTEDATTR                            0x803A000B
#define ZERROR_E_DATABASEFULL                               0x803A000C
#define ZERROR_E_NOMORECHAPTERS                             0x803A000E
#define ZERROR_E_YOUR_DIR_IS_A_FILE                         0x803A0084
#define ZERROR_E_WRITE_ACCESS_DENIED                        0x803A008A

/* Items */

DECLARE_HANDLE(ZMEDIAITEM);

#define ZMEDIAITEM_FMRADIO                                  (ZMEDIAITEM)0x4FFFFFF
#define ZMEDIAITEM_ROOTFOLDER                               (ZMEDIAITEM)0x5FFFFFF
#define ZMEDIAITEM_ROOTPHOTOALBUM                           (ZMEDIAITEM)0xCFFFFFF

typedef enum
{
    ZMEDIAITEM_TYPE_INVALID                               = 0x00,
    ZMEDIAITEM_TYPE_AUDIO                                 = 0x01,
    ZMEDIAITEM_TYPE_VIDEO                                 = 0x02,
    ZMEDIAITEM_TYPE_PICTURE                               = 0x03,
    ZMEDIAITEM_TYPE_UNKNOWN                               = 0x04,
    ZMEDIAITEM_TYPE_FOLDER                                = 0x05,
    ZMEDIAITEM_TYPE_ALBUM                                 = 0x06,
    ZMEDIAITEM_TYPE_PLAYLIST                              = 0x07,
    ZMEDIAITEM_TYPE_ARTIST                                = 0x08,
    ZMEDIAITEM_TYPE_AUDIOGENRE                            = 0x09,
    ZMEDIAITEM_TYPE_VIDEOSERIES                           = 0x0A,
    ZMEDIAITEM_TYPE_DATERANGE                             = 0x0B,
    ZMEDIAITEM_TYPE_PICTUREALBUM                          = 0x0C,
    ZMEDIAITEM_TYPE_USERCARD                              = 0x0D,
    ZMEDIAITEM_TYPE_INBOXMSG                              = 0x0E,
    ZMEDIAITEM_TYPE_PODCASTSERIES                         = 0x0F,
    ZMEDIAITEM_TYPE_PODCASTAUDIO                          = 0x10,
    ZMEDIAITEM_TYPE_AUDIOBOOK                             = 0x11,
    ZMEDIAITEM_TYPE_AUDIOBOOKPART                         = 0x12,
    ZMEDIAITEM_TYPE_GAME                                  = 0x13,
    ZMEDIAITEM_TYPE_GAMERUNTIME                           = 0x14,
    ZMEDIAITEM_TYPE_GAMESTORAGE                           = 0x15,
    ZMEDIAITEM_TYPE_CLOUDTASK                             = 0x16,
    ZMEDIAITEM_TYPE_CLOUDJOB                              = 0x17,
    ZMEDIAITEM_TYPE_CARTENTRY                             = 0x18,
    ZMEDIAITEM_TYPE_QUICKLAUNCH_ITEM                      = 0x19,
    ZMEDIAITEM_TYPE_BOOKMARK                              = 0x1A,
    ZMEDIAITEM_TYPE_RADIOPRESET                           = 0x1B,
    ZMEDIAITEM_TYPE_LETTER                                = 0xFB,
    ZMEDIAITEM_TYPE_TRANSIENTPICTURE                      = 0xFC,
    ZMEDIAITEM_TYPE_TRANSIENTAUDIO                        = 0xFD,
    ZMEDIAITEM_TYPE_FIRMWARE                              = 0xFE,
    _ZMEDIAITEM_TYPE_LIMIT                                = 0xFF
} ZMEDIAITEM_TYPE;

#define ZMEDIAITEM_TYPEOF(item)                             ((ZMEDIAITEM_TYPE)((int)(item) >> 24))

/* Lists */

DECLARE_HANDLE(HZMEDIALIST);

#define ZMEDIALIST_TYPE_INVALID                             0x000
#define ZMEDIALIST_TYPE_ALL_AUDIO                           0x001
#define ZMEDIALIST_TYPE_ALL_ALBUMS                          0x002
#define ZMEDIALIST_TYPE_ALL_ARTISTS                         0x003
#define ZMEDIALIST_TYPE_ALL_AUDIOGENRES                     0x004
#define ZMEDIALIST_TYPE_ALL_PLAYLISTS                       0x005
#define ZMEDIALIST_TYPE_ALL_VIDEOS                          0x006
#define ZMEDIALIST_TYPE_ALL_PICTURES                        0x007
#define ZMEDIALIST_TYPE_ALL_FOLDERS                         0x008
#define ZMEDIALIST_TYPE_ALL_UNKNOWN                         0x009
#define ZMEDIALIST_TYPE_ALL_PICTUREALBUMS                   0x00A
#define ZMEDIALIST_TYPE_ALL_DATERANGES                      0x00B
#define ZMEDIALIST_TYPE_ALL_USERCARDS                       0x00C
#define _ZMEDIALIST_TYPE_UNUSED1                            0x00D
#define ZMEDIALIST_TYPE_ALL_VIDEOSERIES                     0x00E
#define ZMEDIALIST_TYPE_ALL_PODCASTSERIES                   0x00F
#define ZMEDIALIST_TYPE_ALL_PODCASTAUDIO                    0x010
#define _ZMEDIALIST_TYPE_UNUSED2                            0x011
#define ZMEDIALIST_TYPE_ALL_INBOXMSGS                       0x012
/* #define ZMEDIALIST_TYPE_ALL_AUDIO_GROUPBYALBUM           0x    */
/* #define ZMEDIALIST_TYPE_ALL_ALBUMARTISTS                 0x    */
#define ZMEDIALIST_TYPE_ALL_ITEMS_BY_MEDIAID                0x020
#define ZMEDIALIST_TYPE_ALBUM_AUDIO                         0x028
#define ZMEDIALIST_TYPE_ALBUM_CONTENTS                      0x029
#define ZMEDIALIST_TYPE_ARTIST_AUDIO                        0x02A
#define ZMEDIALIST_TYPE_ARTIST_ALBUMS                       0x02B
#define ZMEDIALIST_TYPE_ARTIST_CONTENTS                     0x02C
#define ZMEDIALIST_TYPE_AUDIOGENRE_AUDIO                    0x02D
#define ZMEDIALIST_TYPE_AUDIOGENRE_ALBUMS                   0x02E
#define ZMEDIALIST_TYPE_AUDIOGENRE_CONTENTS                 0x02F
#define ZMEDIALIST_TYPE_PLAYLIST_AUDIO                      0x030
#define ZMEDIALIST_TYPE_PLAYLIST_CONTENTS                   0x031
#define ZMEDIALIST_TYPE_ARTIST_AUDIO_ALL                    0x032
#define ZMEDIALIST_TYPE_ARTIST_AUDIO_ALL_GROUPBYALBUM       0x033
#define ZMEDIALIST_TYPE_DATERANGE_PICTURES                  0x03C
#define ZMEDIALIST_TYPE_DATERANGE_CONTENTS                  0x03D
#define ZMEDIALIST_TYPE_PICTUREALBUM_PICTURES               0x03E
#define ZMEDIALIST_TYPE_PICTUREALBUM_PICTUREALBUMS          0x03F
#define ZMEDIALIST_TYPE_PICTUREALBUM_CONTENTS               0x040
/* #define ZMEDIALIST_TYPE_FOLDER_AUDIO                     0x    */
/* #define ZMEDIALIST_TYPE_FOLDER_VIDEOS                    0x    */
/* #define ZMEDIALIST_TYPE_FOLDER_PICTURES                  0x    */
#define ZMEDIALIST_TYPE_FOLDER_FOLDERS                      0x049
#define ZMEDIALIST_TYPE_FOLDER_UNKNOWNS                     0x04A
#define ZMEDIALIST_TYPE_FOLDER_ALBUMS                       0x04B
#define ZMEDIALIST_TYPE_FOLDER_PLAYLISTS                    0x04C
#define ZMEDIALIST_TYPE_FOLDER_PODCASTAUDIO                 0x04D
#define ZMEDIALIST_TYPE_FOLDER_PODCASTSERIES                0x04E
#define ZMEDIALIST_TYPE_FOLDER_CONTENTS                     0x04F
#define ZMEDIALIST_TYPE_FOLDER_CLOUDCONTENTS                0x050
#define ZMEDIALIST_TYPE_FOLDER_AUDIOBOOKPARTS               0x051
#define ZMEDIALIST_TYPE_FOLDER_GAMES                        0x052
#define ZMEDIALIST_TYPE_FOLDER_ARTISTS                      0x053
/* #define ZMEDIALIST_TYPE_ALL_VIDEOSERIES_OTHER            0x    */
/* #define ZMEDIALIST_TYPE_ALL_VIDEOSERIES_MOVIE            0x    */
/* #define ZMEDIALIST_TYPE_ALL_VIDEOSERIES_TVSHOW           0x    */
/* #define ZMEDIALIST_TYPE_ALL_VIDEOSERIES_MUSICVIDEO       0x    */
/* #define ZMEDIALIST_TYPE_ALL_VIDEOSERIES_PODCAST          0x    */
/* #define ZMEDIALIST_TYPE_ALL_VIDEOSERIES_PERSONAL         0x    */
#define ZMEDIALIST_TYPE_VIDEOSERIES_VIDEOS                  0x064
#define ZMEDIALIST_TYPE_VIDEOSERIES_CONTENTS                0x065
#define ZMEDIALIST_TYPE_ALL_VIDEOS_OTHER                    0x06E
#define ZMEDIALIST_TYPE_ALL_VIDEOS_MOVIE                    0x06F
#define ZMEDIALIST_TYPE_ALL_VIDEOS_TVSHOW                   0x070
#define ZMEDIALIST_TYPE_ALL_VIDEOS_MUSICVIDEO               0x071
#define ZMEDIALIST_TYPE_ALL_VIDEOS_PODCAST                  0x072
#define ZMEDIALIST_TYPE_ALL_VIDEOS_PERSONAL                 0x073
#define ZMEDIALIST_TYPE_ALL_VIDEOS_NONPODCASTS              0x074
#define ZMEDIALIST_TYPE_ALL_PODCASTSERIES_AUDIO             0x078
#define ZMEDIALIST_TYPE_ALL_PODCASTSERIES_VIDEO             0x079
#define ZMEDIALIST_TYPE_PODCASTSERIES_CONTENTS              0x07A
#define ZMEDIALIST_TYPE_PODCASTSERIES_VIDEO                 0x07B
#define ZMEDIALIST_TYPE_PODCASTSERIES_AUDIOPODCASTS         0x07C
#define ZMEDIALIST_TYPE_PODCASTSERIES_CONTENTS_LOCAL        0x07D
#define ZMEDIALIST_TYPE_PODCASTSERIES_CONTENTS_LOCAL_AUDIO  0x07E
#define ZMEDIALIST_TYPE_PODCASTSERIES_CONTENTS_LOCAL_VIDEO  0x07F
/* #define ZMEDIALIST_TYPE_OTHER                            0x    */
#define ZMEDIALIST_TYPE_ALL_CLOUDCONTENT                    0x096
#define ZMEDIALIST_TYPE_ALL_CLOUDCONTENT_AUDIO              0x097
#define ZMEDIALIST_TYPE_ALL_CLOUDCONTENT_ALBUMS             0x098
#define ZMEDIALIST_TYPE_ALL_CLOUDCONTENT_ARTISTS            0x099
#define ZMEDIALIST_TYPE_ALL_CLOUDCONTENT_PLAYLISTS          0x09A
#define ZMEDIALIST_TYPE_ALL_CLOUDCONTENT_AUDIOGENRE         0x09B
/* #define ZMEDIALIST_TYPE_ALL_USERCARDS_FRIENDS            0x    */
#define ZMEDIALIST_TYPE_UNFILTERED_ALBUM_CONTENTS           0x0AA
#define ZMEDIALIST_TYPE_UNFILTERED_ARTIST_CONTENTS          0x0AB
#define ZMEDIALIST_TYPE_UNFILTERED_AUDIOGENRE_CONTENTS      0x0AC
#define ZMEDIALIST_TYPE_UNFILTERED_ARTIST_AUDIO             0x0AD
#define ZMEDIALIST_TYPE_UNFILTERED_FOLDER_CONTENTS          0x0AE
#define ZMEDIALIST_TYPE_ALL_AUDIOBOOKS                      0x0B4
#define ZMEDIALIST_TYPE_ALL_AUDIOBOOKPARTS                  0x0B5
#define ZMEDIALIST_TYPE_AUDIOBOOK_AUDIOBOOKSPARTS           0x0B6
#define ZMEDIALIST_TYPE_ALL_GAMES                           0x0BE
#define ZMEDIALIST_TYPE_ALL_GAMERUNTIMES                    0x0BF
#define ZMEDIALIST_TYPE_ALL_GAMESTORAGES                    0x0C0
#define ZMEDIALIST_TYPE_ALL_GAMES_CREATOR                   0x0C1
#define ZMEDIALIST_TYPE_ALL_GAMES_COMMUNITY                 0x0C2
#define ZMEDIALIST_TYPE_ALL_GAMES_APPLICATIONS              0x0C3
/* #define ZMEDIALIST_TYPE_ALL_CLOUDTASKS                   0x    */
/* #define ZMEDIALIST_TYPE_ALL_CLOUDJOBS                    0x    */
/* #define ZMEDIALIST_TYPE_CLOUDJOB_CLOUDITEMS              0x    */
#define ZMEDIALIST_TYPE_ALL_CARTITEMS                       0x0D2
#define ZMEDIALIST_TYPE_ALL_PLAYLISTS_STATIC                0x0DC
#define ZMEDIALIST_TYPE_ALL_PLAYLISTS_USERCARD              0x0DD
#define ZMEDIALIST_TYPE_ALL_PLAYLISTS_CHANNEL               0x0DE
#define ZMEDIALIST_TYPE_ALL_PLAYLISTS_STATIC_NO_QUICKLIST   0x0DF
/* #define ZMEDIALIST_TYPE_ALL_PLAYLISTS_PICTURETAG         0x    */
/* #define ZMEDIALIST_TYPE_ALL_QUICKLAUNCH                  0x    */
#define ZMEDIALIST_TYPE_QUICKLAUNCH_FAVORITES               0x0E7
#define ZMEDIALIST_TYPE_QUICKLAUNCH_RECENT                  0x0E8
#define ZMEDIALIST_TYPE_QUICKLAUNCH_NEW                     0x0E9
/* #define ZMEDIALIST_TYPE_ALL_BOOKMARKS                    0x    */
/* #define ZMEDIALIST_TYPE_ALL_LETTERS                      0x    */
#define ZMEDIALIST_TYPE_SPECIAL_ALLCHANNELCONTENT           0x104
/* #define ZMEDIALIST_TYPE_SPECIAL_ALLMUSIC                 0x    */
/* #define ZMEDIALIST_TYPE_ALL_TRANSIENTAUDIO               0x    */
/* #define ZMEDIALIST_TYPE_ALL_TRANSIENTPICTURES            0x    */
#define ZMEDIALIST_TYPE_ALL_RADIOPRESETS                    0x122
/* #define ZMEDIALIST_TYPE_PLAYLIST_PICTURETAG              0x    */
/* #define ZMEDIALIST_TYPE_PLAYLIST_PICTUREALBUM            0x    */
#define ZMEDIALIST_TYPE_FOLDER_FOLDERS_NO_SPECIALS          0x12F
#define ZMEDIALIST_TYPE_FOLDER_PICTURECONTENTS              0x130
#define ZMEDIALIST_TYPE_FAVORITE_PICTURES                   0x131
/* #define _ZMEDIALIST_TYPE_LIMIT                           0x    */

/* Attributes and relations */

typedef enum
{
    ZMEDIAITEM_ATTRIBUTE_TYPE_INVALID                     = 0x000000,
    ZMEDIAITEM_ATTRIBUTE_TYPE_INT                         = 0x010000,
    ZMEDIAITEM_ATTRIBUTE_TYPE_STRING                      = 0x020000,
    ZMEDIAITEM_ATTRIBUTE_TYPE_DATETIME                    = 0x030000,
    ZMEDIAITEM_ATTRIBUTE_TYPE_GUID                        = 0x040000,
    ZMEDIAITEM_ATTRIBUTE_TYPE_RELATION                    = 0x100000
} ZMEDIAITEM_ATTRIBUTE_TYPE;

#define ZMEDIAITEM_ATTRIBUTE_TYPEOF(attribute)              ((ZMEDIAITEM_ATTRIBUTE_TYPE)((attribute) & 0xFF0000))

typedef enum
{
    ZMEDIAITEM_INTATTRIBUTE_INVALID                       = 0x10000,
    ZMEDIAITEM_ATTRIBUTE_TRACKNUMBER                      = 0x10001,
    ZMEDIAITEM_ATTRIBUTE_RATING                           = 0x10002,
    ZMEDIAITEM_ATTRIBUTE_DURATION                         = 0x10003,
    ZMEDIAITEM_ATTRIBUTE_FORMATCODE                       = 0x10004,
    ZMEDIAITEM_ATTRIBUTE_PLAYCOUNT                        = 0x10005,
    ZMEDIAITEM_ATTRIBUTE_PLAYWINDOW                       = 0x10006,
    ZMEDIAITEM_ATTRIBUTE_WIDTH                            = 0x10007,
    ZMEDIAITEM_ATTRIBUTE_HEIGHT                           = 0x10008,
    ZMEDIAITEM_ATTRIBUTE_METAGENRE                        = 0x10009,
    ZMEDIAITEM_ATTRIBUTE_FILESIZE                         = 0x1000A,
    ZMEDIAITEM_ATTRIBUTE_DISKNUMBER                       = 0x1000B,
    ZMEDIAITEM_ATTRIBUTE_AUDIOTYPE                        = 0x1000C,
    ZMEDIAITEM_ATTRIBUTE_VIDEOTYPE                        = 0x1000D,
    ZMEDIAITEM_ATTRIBUTE_APPID                            = 0x1000E,
    ZMEDIAITEM_ATTRIBUTE_BOOKMARK                         = 0x1000F,
    ZMEDIAITEM_ATTRIBUTE_FLAGS                            = 0x10010,
    ZMEDIAITEM_ATTRIBUTE_ISSUBSCRIBED                     = 0x10011,
    ZMEDIAITEM_ATTRIBUTE_SORTORDER                        = 0x10012,
    ZMEDIAITEM_ATTRIBUTE_EPISODENUMBER                    = 0x10013,
    ZMEDIAITEM_ATTRIBUTE_SEASONNUMBER                     = 0x10014,
    _ZMEDIAITEM_ATTRIBUTE_ENCOUNTERREAD                   = 0x10015,
    ZMEDIAITEM_ATTRIBUTE_USERCARD_PLAYLIST_TYPE           = 0x10016,
    ZMEDIAITEM_ATTRIBUTE_USERCARDFLAGS                    = 0x10017,
    ZMEDIAITEM_ATTRIBUTE_MEDIAPROPERTIES                  = 0x10018,
    ZMEDIAITEM_ATTRIBUTE_CLOUDCONTENT_REFCOUNT            = 0x10019,
    ZMEDIAITEM_ATTRIBUTE_CS_FLAGS                         = 0x1001A,
    ZMEDIAITEM_ATTRIBUTE_CS_STATE                         = 0x1001B,
    ZMEDIAITEM_ATTRIBUTE_CS_TYPE                          = 0x1001C,
    ZMEDIAITEM_ATTRIBUTE_CS_REFCOUNT                      = 0x1001D,
    ZMEDIAITEM_ATTRIBUTE_CS_POSITION                      = 0x1001E,
    ZMEDIAITEM_ATTRIBUTE_CS_PRIORITY                      = 0x1001F,
    ZMEDIAITEM_ATTRIBUTE_CS_EXECUTERESULT                 = 0x10020,
    ZMEDIAITEM_ATTRIBUTE_CARTMESSAGEID                    = 0x10021,
    ZMEDIAITEM_ATTRIBUTE_CARTITEMTYPE                     = 0x10022,
    ZMEDIAITEM_ATTRIBUTE_PLAYLIST_TYPE                    = 0x10023,
    ZMEDIAITEM_ATTRIBUTE_ISEXPLICIT                       = 0x10024,
    ZMEDIAITEM_ATTRIBUTE_CHANNEL_STATUS                   = 0x10025,
    ZMEDIAITEM_ATTRIBUTE_AUTHENTICATION_REQUIRED          = 0x10027,
    ZMEDIAITEM_ATTRIBUTE_PERSISTEDCLOUDOBJ_PHASE1         = 0x10028,
    ZMEDIAITEM_ATTRIBUTE_PERSISTEDCLOUDOBJ_PHASE2         = 0x10029,
    ZMEDIAITEM_ATTRIBUTE_CLOUD_PLAYCOUNT                  = 0x1002A,
    ZMEDIAITEM_ATTRIBUTE_CLOUD_SKIPCOUNT                  = 0x1002B,
    ZMEDIAITEM_ATTRIBUTE_GAME_FLAGS                       = 0x1002C,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_LIST                 = 0x1002D,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEMTYPE             = 0x1002E,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEMORDER            = 0x1002F,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEMDATA             = 0x10030,
    ZMEDIAITEM_ATTRIBUTE_INBOXMSG_MSGID                   = 0x10031,
    ZMEDIAITEM_ATTRIBUTE_INBOXMSG_TYPE                    = 0x10032,
    ZMEDIAITEM_ATTRIBUTE_CLIPTYPE                         = 0x10033,
    ZMEDIAITEM_ATTRIBUTE_CS_PERSISTHANDLEVALUE            = 0x10034,
    ZMEDIAITEM_ATTRIBUTE_CLOUD_PLAYTIME                   = 0x10035,
    ZMEDIAITEM_ATTRIBUTE_ARTISTVIEW_FILLERFILE_PRESENT    = 0x10036,
    ZMEDIAITEM_ATTRIBUTE_LICENSE_STATE                    = 0x10037,
    ZMEDIAITEM_ATTRIBUTE_EXPERIMENT_ID                    = 0x10038,
    ZMEDIAITEM_ATTRIBUTE_MAX_LOCAL_SERIES_ITEMS           = 0x10039,
    ZMEDIAITEM_ATTRIBUTE_SERIES_REFRESH_INTERVAL          = 0x1003A,
    ZMEDIAITEM_ATTRIBUTE_DOWNLOAD_STATE                   = 0x1003B,
    ZMEDIAITEM_ATTRIBUTE_DOWNLOAD_TYPE                    = 0x1003C,
    ZMEDIAITEM_ATTRIBUTE_PODCAST_TYPE                     = 0x1003D,
    ZMEDIAITEM_ATTRIBUTE_SUBSCRIPTION_STATE               = 0x1003E,
    ZMEDIAITEM_ATTRIBUTE_ITEM_ACQUIRED_TYPE               = 0x1003F,
    ZMEDIAITEM_ATTRIBUTE_PODCAST_DOWNLOAD_PROGRESS        = 0x10040,
    ZMEDIAITEM_ATTRIBUTE_ITEM_LATITUDE                    = 0x10041,
    ZMEDIAITEM_ATTRIBUTE_ITEM_LONGITUDE                   = 0x10042,
    ZMEDIAITEM_ATTRIBUTE_PLAYLIST_PICTUREALBUM            = 0x10043,
    ZMEDIAITEM_ATTRIBUTE_FM_FREQUENCY                     = 0x10044,
    ZMEDIAITEM_ATTRIBUTE_RADIO_REGION                     = 0x10045,
    ZMEDIAITEM_ATTRIBUTE_TRANSIENTITEM_ACTUALTYPE         = 0x10046,
    ZMEDIAITEM_ATTRIBUTE_SRCPATHHASH_FORMEDIAGROVELER     = 0x10047,
    ZMEDIAITEM_ATTRIBUTE_ITEM_HEADING                     = 0x10048,
    ZMEDIAITEM_ATTRIBUTE_ITEM_ALTITUDE                    = 0x10049,
    ZMEDIAITEM_ATTRIBUTE_ITEM_ORIENTATION                 = 0x1004A,
    ZMEDIAITEM_ATTRIBUTE_PICTURE_RATING                   = 0x1004B,
    ZMEDIAITEM_ATTRIBUTE_CARTENTRY_NUM_ATTEMPTS           = 0x1004C,
    ZMEDIAITEM_ATTRIBUTE_CARTENTRY_LAST_ERROR             = 0x1004D,
    ZMEDIAITEM_ATTRIBUTE_CARTENTRY_DOWNLOAD_PROGRESS      = 0x1004E,
    ZMEDIAITEM_ATTRIBUTE_ITEM_LASTERROR                   = 0x1004F,
    ZMEDIAITEM_ATTRIBUTE_DORADO_PLAYLIST_TYPE             = 0x10050,
    ZMEDIAITEM_ATTRIBUTE_DORADO_PLAYLIST_EXTENDED_TYPE    = 0x10051,
    ZMEDIAITEM_ATTRIBUTE_DORADO_PLAYLIST_COMPLETE         = 0x10052,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEM_CONTEXT         = 0x10053,
    _ZMEDIAITEM_INTATTRIBUTE_LIMIT                        = 0x10054
} ZMEDIAITEM_INTATTRIBUTE;

typedef enum
{
    ZMEDIAITEM_STRINGATTRIBUTE_INVALID                    = 0x20000,
    ZMEDIAITEM_ATTRIBUTE_NAME                             = 0x20001,
    ZMEDIAITEM_ATTRIBUTE_ARTIST                           = 0x20002,
    ZMEDIAITEM_ATTRIBUTE_ALBUM                            = 0x20003,
    ZMEDIAITEM_ATTRIBUTE_GENRE                            = 0x20004,
    ZMEDIAITEM_ATTRIBUTE_PARENTALRATING                   = 0x20005,
    ZMEDIAITEM_ATTRIBUTE_DESCRIPTION                      = 0x20006,
    ZMEDIAITEM_ATTRIBUTE_GUIDETEXT                        = 0x20007,
    ZMEDIAITEM_ATTRIBUTE_VIDEOSERIES                      = 0x20008,
    ZMEDIAITEM_ATTRIBUTE_PODCASTSERIES                    = 0x20009,
    ZMEDIAITEM_ATTRIBUTE_FILEPATH                         = 0x2000A,
    ZMEDIAITEM_ATTRIBUTE_ARTPATH                          = 0x2000B,
    ZMEDIAITEM_ATTRIBUTE_FILENAME                         = 0x2000C,
    ZMEDIAITEM_ATTRIBUTE_URL                              = 0x2000D,
    ZMEDIAITEM_ATTRIBUTE_SOURCE                           = 0x2000E,
    ZMEDIAITEM_ATTRIBUTE_USERSTATUS                       = 0x2000F,
    ZMEDIAITEM_ATTRIBUTE_ZUNETAG                          = 0x20010,
    ZMEDIAITEM_ATTRIBUTE_USERGUID                         = 0x20011,
    ZMEDIAITEM_ATTRIBUTE_BACKGROUND_PATH                  = 0x20012,
    ZMEDIAITEM_ATTRIBUTE_USERFRIENDLYNAME                 = 0x20013,
    ZMEDIAITEM_ATTRIBUTE_ARTURL                           = 0x20014,
    ZMEDIAITEM_ATTRIBUTE_INBOXMSG_CONTENT                 = 0x20015,
    ZMEDIAITEM_ATTRIBUTE_VERSION                          = 0x20016,
    ZMEDIAITEM_ATTRIBUTE_KID                              = 0x20017,
    ZMEDIAITEM_ATTRIBUTE_COPYRIGHT                        = 0x20018,
    ZMEDIAITEM_ATTRIBUTE_REQUIREDFIRMWARE                 = 0x20019,
    ZMEDIAITEM_ATTRIBUTE_NAME_RAW                         = 0x2001A,
    ZMEDIAITEM_ATTRIBUTE_CARTENTRY_OFFER_ID               = 0x2001B,
    ZMEDIAITEM_ATTRIBUTE_CARTENTRY_ITEM_NAME              = 0x2001C,
    ZMEDIAITEM_ATTRIBUTE_ARTPATH_SMALL                    = 0x2001D,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEM_TEXT            = 0x2001E,
    ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEM_DISPLAYART      = 0x2001F,
    _ZMEDIAITEM_STRINGATTRIBUTE_LIMIT                     = 0x20020
} ZMEDIAITEM_STRINGATTRIBUTE;

typedef enum
{
    ZMEDIAITEM_DATETIMEATTRIBUTE_INVALID                  = 0x30000,
    ZMEDIAITEM_ATTRIBUTE_DATE                             = 0x30001,
    ZMEDIAITEM_ATTRIBUTE_FEEDLASTUPDATED                  = 0x30002,
    ZMEDIAITEM_ATTRIBUTE_LASTPLAYEDTIME                   = 0x30003,
    ZMEDIAITEM_ATTRIBUTE_LICENSEEXPIREDATE                = 0x30004,
    ZMEDIAITEM_ATTRIBUTE_LAST_MODIFIED                    = 0x30005,
    ZMEDIAITEM_ATTRIBUTE_FAVORITE_DATE                    = 0x30006,
    _ZMEDIAITEM_DATETIMEATTRIBUTE_LIMIT                   = 0x30007
} ZMEDIAITEM_DATETIMEATTRIBUTE;

typedef enum
{
    ZMEDIAITEM_GUIDATTRIBUTE_INVALID                      = 0x40000,
    ZMEDIAITEM_ATTRIBUTE_MEDIAID                          = 0x40001,
    ZMEDIAITEM_ATTRIBUTE_VIRTUALAPPID                     = 0x40002,
    ZMEDIAITEM_ATTRIBUTE_PARENT_MEDIAID                   = 0x40003,
    _ZMEDIAITEM_GUIDATTRIBUTE_LIMIT                       = 0x40004
} ZMEDIAITEM_GUIDATTRIBUTE;

typedef enum
{
    ZMEDIAITEM_RELATION_INVALID                           = 0x100000,
    ZMEDIAITEM_RELATION_ARTIST                            = 0x100001,
    ZMEDIAITEM_RELATION_ALBUM                             = 0x100002,
    ZMEDIAITEM_RELATION_GENRE                             = 0x100003,
    ZMEDIAITEM_RELATION_DATERANGE                         = 0x100004,
    ZMEDIAITEM_RELATION_PICTUREALBUM                      = 0x100005,
    ZMEDIAITEM_RELATION_VIDEOSERIES                       = 0x100006,
    ZMEDIAITEM_RELATION_PODCASTSERIES                     = 0x100007,
    ZMEDIAITEM_RELATION_USERCARD                          = 0x100008,
    ZMEDIAITEM_RELATION_FOLDER                            = 0x100009,
    _ZMEDIAITEM_RELATION_UNUSED                           = 0x10000A,
    ZMEDIAITEM_RELATION_AUDIOBOOK                         = 0x10000B,
    ZMEDIAITEM_RELATION_CLOUDJOB                          = 0x10000C,
    ZMEDIAITEM_RELATION_INBOXMSG_MEDIAITEM                = 0x10000D,
    _ZMEDIAITEM_RELATION_LIMIT                            = 0x10000E
} ZMEDIAITEM_RELATION;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_RATING (0x10002) */
{
    ZMEDIAITEM_RATING_UNRATED,
    ZMEDIAITEM_RATING_DISLIKE_MOST,
    ZMEDIAITEM_RATING_DISLIKE_MORE,
    ZMEDIAITEM_RATING_DISLIKE,
    ZMEDIAITEM_RATING_DISLIKE_SOMEWHAT,
    ZMEDIAITEM_RATING_DISLIKE_NEUTRAL,
    ZMEDIAITEM_RATING_LIKE_NEUTRAL,
    ZMEDIAITEM_RATING_LIKE_SOMEWHAT,
    ZMEDIAITEM_RATING_LIKE,
    ZMEDIAITEM_RATING_LIKE_MORE,
    ZMEDIAITEM_RATING_LIKE_MOST,
    _ZMEDIAITEM_RATING_COUNT
    /* ZMEDIAITEM_RATING_HATEIT */
    /* ZMEDIAITEM_RATING_LOVEIT */
    /* _ZMEDIAITEM_RATING_POSITIVE */
} ZMEDIAITEM_RATING;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_SORTORDER (0x10012) */
{
    ZMEDIAITEM_SORTORDER_NONE,
    ZMEDIAITEM_SORTORDER_NEWEST_FIRST,
    ZMEDIAITEM_SORTORDER_OLDEST_FIRST
} ZMEDIAITEM_SORTORDER;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_VIDEOTYPE (0x1000D) */
{
    ZMEDIAITEM_VIDEOTYPE_INVALID,
    ZMEDIAITEM_VIDEOTYPE_OTHER,
    ZMEDIAITEM_VIDEOTYPE_MOVIE,
    ZMEDIAITEM_VIDEOTYPE_PODCAST,
    ZMEDIAITEM_VIDEOTYPE_TVSHOW,
    ZMEDIAITEM_VIDEOTYPE_MUSICVIDEO,
    ZMEDIAITEM_VIDEOTYPE_PERSONAL,
    _ZMEDIAITEM_VIDEOTYPE_COUNT
} ZMEDIAITEM_VIDEOTYPE;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_FLAGS (0x10010) */
{
    ZMEDIAITEM_FLAG_DRMPROTECTED = 1,
    ZMEDIAITEM_FLAG_CONSUMED = 2,
    ZMEDIAITEM_FLAG_PREVENT_COPYTOHOST = 8
} ZMEDIAITEM_FLAGS;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_ITEM_ACQUIRED_TYPE (0x1003F) */
{
    ZMEDIAITEM_FLAG_CAPTURED_ON_DEVICE = 1,
    ZMEDIAITEM_FLAG_RECEIVED_ON_DEVICE = 2,
    ZMEDIAITEM_FLAG_PRELOADED_ON_DEVICE = 3
} ZMEDIAITEM_ITEM_ACQUIRED_TYPE;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_USERCARDFLAGS (0x10017) */
{
    ZMEDIAITEM_USERCARDFLAG_FRIEND = 2
} ZMEDIAITEM_USERCARDFLAGS;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_PLAYLIST_TYPE (0x10023) */
{
    ZMEDIAITEM_PLAYLIST_TYPE_STATIC = 1,
    ZMEDIAITEM_PLAYLIST_TYPE_CHANNEL = 2
} ZMEDIAITEM_PLAYLIST_TYPE;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_CHANNEL_STATUS (0x10025) */
{
    ZMEDIAITEM_CHANNEL_STATUS_ERROR = 4
} ZMEDIAITEM_CHANNEL_STATUS;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_LIST (0x1002D) */
{
    ZMEDIAITEM_QUICKLAUNCH_LIST_FAVORITES = 1,
    ZMEDIAITEM_QUICKLAUNCH_LIST_NEW = 2,
    ZMEDIAITEM_QUICKLAUNCH_LIST_RECENT = 3
} ZMEDIAITEM_QUICKLAUNCH_LIST;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_QUICKLAUNCH_ITEMTYPE (0x1002E) */
{
    ZMEDIAITEM_QUICKLAUNCH_ITEMTYPE_ZMEDIAITEM = 1,
    ZMEDIAITEM_QUICKLAUNCH_ITEMTYPE_RADIO = 2,
    ZMEDIAITEM_QUICKLAUNCH_ITEMTYPE_THIRD_PARTY = 4
} ZMEDIAITEM_QUICKLAUNCH_ITEMTYPE;

typedef enum /* ZMEDIAITEM_ATTRIBUTE_LICENSE_STATE (0x10037) */
{
    ZMEDIAITEM_LICENSESTATE_USEUNTIL = 2
} ZMEDIAITEM_LICENSESTATE;

/* Media library */

typedef enum
{
    ZMEDIAITEM_THUMBTYPE_NORMAL,
    ZMEDIAITEM_THUMBTYPE_TINY
} ZMEDIAITEM_THUMBTYPE;

typedef enum
{
    ZMEDIAITEM_VISIBILITY_LIBRARY,
    ZMEDIAITEM_VISIBILITY_HIDDEN,
    ZMEDIAITEM_VISIBILITY_CLOUD
} ZMEDIAITEM_VISIBILITY;

#ifdef ZUNE_SD
HRESULT WINAPI ZMediaLib_AddItem(ZMEDIAITEM_TYPE type, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaLib_ClearPlaylist(ZMEDIAITEM playlist);
HRESULT WINAPI ZMediaLib_CreateList(DWORD type, ZMEDIAITEM parameter, HZMEDIALIST *list);
HRESULT WINAPI ZMediaLib_GetItemDateTimeAttribute(ZMEDIAITEM item, ZMEDIAITEM_DATETIMEATTRIBUTE attribute, FILETIME *value);
HRESULT WINAPI ZMediaLib_GetItemGuidAttribute(ZMEDIAITEM item, ZMEDIAITEM_GUIDATTRIBUTE attribute, GUID *value);
HRESULT WINAPI ZMediaLib_GetItemIntAttribute(ZMEDIAITEM item, ZMEDIAITEM_INTATTRIBUTE attribute, int *value);
HRESULT WINAPI ZMediaLib_GetItemStringAttribute(ZMEDIAITEM item, ZMEDIAITEM_STRINGATTRIBUTE attribute, LPWSTR buffer, size_t maxLength, size_t *actualLength);
HRESULT WINAPI ZMediaLib_GetItemThumbnail(ZMEDIAITEM item, ZMEDIAITEM_THUMBTYPE type, void *buffer, size_t maxLength, size_t *actualLength);
HRESULT WINAPI ZMediaLib_GetItemVisibility(ZMEDIAITEM item, ZMEDIAITEM_VISIBILITY *visibility);
HRESULT WINAPI ZMediaLib_GetNamedItemAttribute(ZMEDIAITEM item, LPCWSTR attributeName, void *buffer, size_t maxLength, size_t *actualLength);
HRESULT WINAPI ZMediaLib_GetRelatedItem(ZMEDIAITEM near, ZMEDIAITEM_RELATION relation, ZMEDIAITEM *far);
HRESULT WINAPI ZMediaLib_IncrementItemIntAttribute(ZMEDIAITEM item, ZMEDIAITEM_INTATTRIBUTE attribute, int increment, int *newValue);
HRESULT WINAPI ZMediaLib_SetItemDateTimeAttribute(ZMEDIAITEM item, ZMEDIAITEM_DATETIMEATTRIBUTE attribute, const FILETIME *value);
HRESULT WINAPI ZMediaLib_SetItemGuidAttribute(ZMEDIAITEM item, ZMEDIAITEM_GUIDATTRIBUTE attribute, GUID value);
HRESULT WINAPI ZMediaLib_SetItemIntAttribute(ZMEDIAITEM item, ZMEDIAITEM_INTATTRIBUTE attribute, int value);
HRESULT WINAPI ZMediaLib_SetItemStringAttribute(ZMEDIAITEM item, ZMEDIAITEM_STRINGATTRIBUTE attribute, LPCWSTR value);
HRESULT WINAPI ZMediaLib_SetItemThumbnail(ZMEDIAITEM item, void *buffer, size_t length);
HRESULT WINAPI ZMediaLib_SetItemVisibility(ZMEDIAITEM item, ZMEDIAITEM_VISIBILITY visibility);
HRESULT WINAPI ZMediaLib_SetLocale(LCID locale);
HRESULT WINAPI ZMediaLib_SetNamedItemAttribute(ZMEDIAITEM item, LPCWSTR attributeName, void *buffer, size_t length);
HRESULT WINAPI ZMediaLib_SetRelatedItem(ZMEDIAITEM near, ZMEDIAITEM_RELATION relation, ZMEDIAITEM far);
HRESULT WINAPI ZMediaLib_UpdateItemThumbnail(ZMEDIAITEM item, ZMEDIAITEM_THUMBTYPE type);
HRESULT WINAPI ZMediaLib_ValidateItem(ZMEDIAITEM item);
HRESULT WINAPI ZMediaList_AddRef(HZMEDIALIST list);
HRESULT WINAPI ZMediaList_FindItemByGuidAttribute(HZMEDIALIST list, ZMEDIAITEM_INTATTRIBUTE attribute, const GUID *value, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaList_FindItemByIntAttribute(HZMEDIALIST list, ZMEDIAITEM_INTATTRIBUTE attribute, int value, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaList_FindItemByStringAttribute(HZMEDIALIST list, ZMEDIAITEM_STRINGATTRIBUTE attribute, LPCWSTR value, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaList_Flatten(HZMEDIALIST list, HZMEDIALIST *result);
HRESULT WINAPI ZMediaList_GetItem(HZMEDIALIST list, int index, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaList_GetItemCount(HZMEDIALIST list, DWORD *count);
HRESULT WINAPI ZMediaList_GetItems(HZMEDIALIST list, DWORD start, ZMEDIAITEM items[], size_t maxCount, size_t *actualCount);
HRESULT WINAPI ZMediaList_GetType(HZMEDIALIST list, DWORD *type, ZMEDIAITEM *parameter);
HRESULT WINAPI ZMediaList_Release(HZMEDIALIST list);
/* ZMediaLib_AddPlaylistItem */
/* ZMediaLib_AddYamanoteQuicklaunchItem */
/* ZMediaLib_FilterList */
/* ZMediaLib_Flush */
/* ZMediaLib_GetItemStreamOnProperty */
/* ZMediaLib_GetNotifyEvent */
/* ZMediaLib_GetSizeItemStream */
/* ZMediaLib_GetSpecialItem */
/* ZMediaLib_GetStats */
/* ZMediaLib_Init */
/* ZMediaLib_IsAsyncEnabled */
/* ZMediaLib_IsItemArtPresent */
/* ZMediaLib_IsOpen */
/* ZMediaLib_IsSpecialItem */
/* ZMediaLib_Open */
/* ZMediaLib_OpenEx */
/* ZMediaLib_ReIndex */
/* ZMediaLib_ReadItemStream */
/* ZMediaLib_RemoveItem */
/* ZMediaLib_RemovePlaylistItem */
/* ZMediaLib_Repair */
/* ZMediaLib_ReportItemAcquired */
/* ZMediaLib_ReportItemModified */
/* ZMediaLib_RequireLibrary */
/* ZMediaLib_SeekItemStream */
/* ZMediaLib_TransferLock */
/* ZMediaLib_UpdateItemThumbnails */
/* ZMediaLib_WriteLock */
/* ZMediaList_AddLetters */
/* ZMediaList_FlattenEx */
/* ZMediaList_GetItemIndex */
/* ZMediaList_GetTypeItemCount */
#endif

/* Media queue */

typedef enum
{
    ZMEDIAQUEUE_INVALID,
    ZMEDIAQUEUE_AUDIO,
    ZMEDIAQUEUE_VIDEO,
    ZMEDIAQUEUE_PICTURES,
    ZMEDIAQUEUE_AUDIOPODCAST,
    ZMEDIAQUEUE_AUDIOBOOK,
    ZMEDIAQUEUE_TRANSIENTAUDIO,
    ZMEDIAQUEUE_RADIO,
    ZMEDIAQUEUE_INLINEAUDIO,
    ZMEDIAQUEUE_INLINEVIDEO,
    _ZMEDIAQUEUE_COUNT,
    ZMEDIAQUEUE_ALL = -1
} ZMEDIAQUEUE;

#ifdef ZUNE_HD
typedef enum
{
    ZMEDIAQUEUE_AUDIOENDPOINT_INVALID,
    ZMEDIAQUEUE_AUDIOENDPOINT_AUTO,
    ZMEDIAQUEUE_AUDIOENDPOINT_HEADSET,
    ZMEDIAQUEUE_AUDIOENDPOINT_SPEAKER
} ZMEDIAQUEUE_AUDIOENDPOINT;
#endif

typedef enum
{
    ZMEDIAQUEUE_MOVEFLAGS_NONE = 0,
    ZMEDIAQUEUE_MOVEFLAGS_PRESERVEBOOKMARK = 1
} ZMEDIAQUEUE_MOVEFLAGS;

typedef enum
{
    ZMEDIAQUEUE_PLAYFLAGS_NONE = 0,
    ZMEDIAQUEUE_PLAYFLAGS_SHUFFLE = 1,
    ZMEDIAQUEUE_PLAYFLAGS_REPEAT = 2
} ZMEDIAQUEUE_PLAYFLAGS;

typedef enum
{
    ZMEDIAQUEUE_PLAYSTATE_INVALID,
    ZMEDIAQUEUE_PLAYSTATE_UNKNOWN,
    ZMEDIAQUEUE_PLAYSTATE_LOADING,
    ZMEDIAQUEUE_PLAYSTATE_PLAYING,
    ZMEDIAQUEUE_PLAYSTATE_PAUSED,
    ZMEDIAQUEUE_PLAYSTATE_STOPPED,
    ZMEDIAQUEUE_PLAYSTATE_FASTFORWARDING,
    ZMEDIAQUEUE_PLAYSTATE_REWINDING,
    _ZMEDIAQUEUE_PLAYSTATE_COUNT
} ZMEDIAQUEUE_PLAYSTATE;

typedef enum
{
    ZMEDIAQUEUE_PROGRESSIVEPLAYMODE_OFF = 1,
    ZMEDIAQUEUE_PROGRESSIVEPLAYMODE_FORWARD = 2,
    ZMEDIAQUEUE_PROGRESSIVEPLAYMODE_REVERSE = 3
} ZMEDIAQUEUE_PROGRESSIVEPLAYMODE;

#ifdef ZUNE_HD
typedef enum
{
    ZMEDIAQUEUE_PROPERTY_AUDIOROUTINGPREFERENCE = 9, /* => ZMEDIAQUEUE_AUDIOENDPOINT */
    ZMEDIAQUEUE_PROPERTY_RADIO_ANTENNATYPE = 10      /* => ZMEDIAQUEUE_RADIO_ANTENNATYPE */
} ZMEDIAQUEUE_PROPERTY;

typedef enum
{
    ZMEDIAQUEUE_RADIO_ANTENNATYPE_EXTERNAL,
    ZMEDIAQUEUE_RADIO_ANTENNATYPE_INTERNAL
} ZMEDIAQUEUE_RADIO_ANTENNATYPE;
#endif

typedef enum
{
    ZMEDIAQUEUE_RADIOREGION_INVALID,
    ZMEDIAQUEUE_RADIOREGION_USA,
    ZMEDIAQUEUE_RADIOREGION_EUROPE,
    ZMEDIAQUEUE_RADIOREGION_JAPAN
} ZMEDIAQUEUE_RADIOREGION;

typedef enum
{
    ZMEDIAQUEUE_STATIONTEXT_NAME = 0,
    ZMEDIAQUEUE_STATIONTEXT_CALLSIGN = 1,
    ZMEDIAQUEUE_STATIONTEXT_DESCRIPTION = 2
} ZMEDIAQUEUE_STATIONTEXT;

#ifdef ZUNE_SD
HRESULT WINAPI ZMediaQueue_AddItem(ZMEDIAQUEUE queue, ZMEDIAITEM item);
HRESULT WINAPI ZMediaQueue_ClearDrmProtected(ZMEDIAQUEUE queue);
HRESULT WINAPI ZMediaQueue_Clear(ZMEDIAQUEUE queue);
#ifdef ZUNE_HD
HRESULT WINAPI ZMediaQueue_ForceUnlock(ZMEDIAQUEUE queue);
#endif
HRESULT WINAPI ZMediaQueue_GetCurrentItem(ZMEDIAQUEUE queue, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaQueue_GetFrequencyRange(ZMEDIAQUEUE queue, DWORD *minFreq, DWORD *maxFreq, DWORD *step);
HRESULT WINAPI ZMediaQueue_GetItemCount(ZMEDIAQUEUE queue, DWORD *count);
HRESULT WINAPI ZMediaQueue_GetItemMediaAt(ZMEDIAQUEUE queue, DWORD index, ZMEDIAITEM *item);
HRESULT WINAPI ZMediaQueue_GetPlayDuration(ZMEDIAQUEUE queue, DWORD *duration);
HRESULT WINAPI ZMediaQueue_GetPlayFlags(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PLAYFLAGS *flags);
HRESULT WINAPI ZMediaQueue_GetPlayPosition(ZMEDIAQUEUE queue, DWORD *position);
HRESULT WINAPI ZMediaQueue_GetPlayState(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PLAYSTATE *state);
HRESULT WINAPI ZMediaQueue_GetProgressivePlayMode(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PROGRESSIVEPLAYMODE *mode);
#ifdef ZUNE_HD
HRESULT WINAPI ZMediaQueue_GetProperty(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PROPERTY prop, DWORD *value);
#endif
HRESULT WINAPI ZMediaQueue_GetRadioRegion(ZMEDIAQUEUE queue, ZMEDIAQUEUE_RADIOREGION *region);
HRESULT WINAPI ZMediaQueue_GetSourceList(ZMEDIAQUEUE queue, HZMEDIALIST *list);
HRESULT WINAPI ZMediaQueue_GetStationText(ZMEDIAQUEUE queue, ZMEDIAQUEUE_STATIONTEXT field, LPWSTR buffer, size_t length);
HRESULT WINAPI ZMediaQueue_GetVolume(ZMEDIAQUEUE queue, int *volume);
HRESULT WINAPI ZMediaQueue_IsBuffering(ZMEDIAQUEUE queue, BOOL *buffering);
HRESULT WINAPI ZMediaQueue_IsMuted(ZMEDIAQUEUE queue, BOOL *muted);
HRESULT WINAPI ZMediaQueue_IsSeeking(ZMEDIAQUEUE queue, BOOL *seeking);
HRESULT WINAPI ZMediaQueue_IsVizEnabled(ZMEDIAQUEUE queue, BOOL enabled);
HRESULT WINAPI ZMediaQueue_Lock(ZMEDIAQUEUE queue, BOOL lock);
HRESULT WINAPI ZMediaQueue_MoveNext(ZMEDIAQUEUE queue);
HRESULT WINAPI ZMediaQueue_MoveNextEx(ZMEDIAQUEUE queue, ZMEDIAQUEUE_MOVEFLAGS flags);
HRESULT WINAPI ZMediaQueue_MovePrev(ZMEDIAQUEUE queue);
HRESULT WINAPI ZMediaQueue_MovePrevEx(ZMEDIAQUEUE queue, ZMEDIAQUEUE_MOVEFLAGS flags);
HRESULT WINAPI ZMediaQueue_PlayItem(ZMEDIAQUEUE queue, ZMEDIAITEM item);
HRESULT WINAPI ZMediaQueue_PlayList(ZMEDIAQUEUE queue, HZMEDIALIST list, DWORD startAt);
#ifdef ZUNE_HD
HRESULT WINAPI ZMediaQueue_RecommendQueueForUrl(LPCWSTR url, ZMEDIAQUEUE *queue);
HRESULT WINAPI ZMediaQueue_RestoreContents(ZMEDIAQUEUE queue);
#endif
HRESULT WINAPI ZMediaQueue_Resync(ZMEDIAQUEUE queue);
#ifdef ZUNE_HD
HRESULT WINAPI ZMediaQueue_SaveContents(ZMEDIAQUEUE queue);
#endif
HRESULT WINAPI ZMediaQueue_SetPlayDuration(ZMEDIAQUEUE queue, DWORD duration);
HRESULT WINAPI ZMediaQueue_SetPlayPosition(ZMEDIAQUEUE queue, DWORD position);
HRESULT WINAPI ZMediaQueue_SetPlayState(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PLAYSTATE state);
HRESULT WINAPI ZMediaQueue_SetProgressivePlayMode(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PROGRESSIVEPLAYMODE mode);
#ifdef ZUNE_HD
HRESULT WINAPI ZMediaQueue_SetProperty(ZMEDIAQUEUE queue, ZMEDIAQUEUE_PROPERTY prop, DWORD value);
#endif
HRESULT WINAPI ZMediaQueue_SetRadioRegion(ZMEDIAQUEUE queue, ZMEDIAQUEUE_RADIOREGION region);
#ifdef ZUNE_HD
HRESULT WINAPI ZMediaQueue_SetRepeatSingle(ZMEDIAQUEUE queue, BOOL enabled);
#endif
HRESULT WINAPI ZMediaQueue_SetRepeat(ZMEDIAQUEUE queue, BOOL enabled);
HRESULT WINAPI ZMediaQueue_SetShuffle(ZMEDIAQUEUE queue, BOOL enabled);
HRESULT WINAPI ZMediaQueue_SetVolume(ZMEDIAQUEUE queue, int volume);
HRESULT WINAPI ZMediaQueue_StopSeek(ZMEDIAQUEUE queue);
HRESULT WINAPI ZMediaQueue_WaitForSeekComplete(ZMEDIAQUEUE queue, DWORD timeout);
/* ZMediaQueue_AcquireDrmLicenseSilent */
/* ZMediaQueue_BindLicense */
/* ZMediaQueue_ClearAllExcept */
/* ZMediaQueue_EnableEventNotification */
/* ZMediaQueue_EnableStationData */
/* ZMediaQueue_EnableViz */
/* ZMediaQueue_FindItem */
/* ZMediaQueue_GenerateDrmChallenge */
/* ZMediaQueue_GetCurrentChapterTitle */
/* ZMediaQueue_GetCurrentItemArt */
/* ZMediaQueue_GetCurrentItemMedia */
/* ZMediaQueue_GetDestRect */
/* ZMediaQueue_GetDigitalSignalQuality */
/* ZMediaQueue_GetDrmHeader */
/* ZMediaQueue_GetErrorState */
/* ZMediaQueue_GetFrequency */
/* ZMediaQueue_GetIDI */
/* ZMediaQueue_GetNativeVideoSize */
/* ZMediaQueue_GetNonEmptyQueueMask */
/* ZMediaQueue_GetNotification */
/* ZMediaQueue_GetRTPlusTags */
/* ZMediaQueue_GetRichMetaData */
/* ZMediaQueue_GetSignalQuality */
/* ZMediaQueue_GetSrcRect */
/* ZMediaQueue_GetStationGenre */
/* ZMediaQueue_GetVizData */
/* ZMediaQueue_GetZoomMode */
/* ZMediaQueue_InsertItem */
/* ZMediaQueue_IsIDIEnabled */
/* ZMediaQueue_IsRTPlusDataEnabled */
/* ZMediaQueue_IsShowing */
/* ZMediaQueue_IsStationDataEnabled */
/* ZMediaQueue_MoveNextChapter */
/* ZMediaQueue_MovePrevChapter */
/* ZMediaQueue_MoveToEx */
/* ZMediaQueue_MoveTo */
/* ZMediaQueue_Mute */
/* ZMediaQueue_NudgeFrequency */
/* ZMediaQueue_ProcessDrmResponse */
/* ZMediaQueue_RecoverError */
/* ZMediaQueue_RegisterForNotifications */
/* ZMediaQueue_RemoveItem */
/* ZMediaQueue_ReportSkip */
/* ZMediaQueue_SetEQ */
/* ZMediaQueue_SetFrequency */
/* ZMediaQueue_SetSrcRect */
/* ZMediaQueue_SetVideoSessionHandle */
/* ZMediaQueue_SetZoomMode */
/* ZMediaQueue_Show */
/* ZMediaQueue_SkipChapter */
/* ZMediaQueue_SkipFixedIncrement */
/* ZMediaQueue_SkipTrack */
/* ZMediaQueue_StartSeekToFrequency */
/* ZMediaQueue_StartSeekToNextStation */
#endif

#ifdef __cplusplus
}
#endif
#endif
