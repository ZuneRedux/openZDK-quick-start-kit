﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zdkmedia.h => zdksystem.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZDKMEDIA_H
#define _ZDKMEDIA_H
#include <windows.h>
#include "zdkdisplay.h"
#include "zmedia.h"
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck
 *****************************************************************************/

/* Initialization */

HRESULT WINAPI ZDKMedia_Initialize();
HRESULT WINAPI ZDKMedia_Shutdown();

/* Media library */

typedef enum
{
    ITEM_TYPE_SONG      = 1,
    ITEM_TYPE_ARTIST    = 2,
    ITEM_TYPE_ALBUM     = 3,
    ITEM_TYPE_PLAYLIST  = 4,
    ITEM_TYPE_GENRE     = 5,
    ITEM_TYPE_PICTURE   = 6,
    ITEM_TYPE_DIRECTORY = 7
} ZDK_ITEM_TYPE;

HRESULT WINAPI ZDKMedia_Album_GetArtist(ZMEDIAITEM album, ZMEDIAITEM *artist);
HRESULT WINAPI ZDKMedia_Album_GetDuration(ZMEDIAITEM album, int *duration);
HRESULT WINAPI ZDKMedia_Album_GetGenre(ZMEDIAITEM album, ZMEDIAITEM *genre);
HRESULT WINAPI ZDKMedia_Album_GetSongs(ZMEDIAITEM album, HZMEDIALIST *songs);
HRESULT WINAPI ZDKMedia_Album_GetTexture(ZMEDIAITEM album, HTEXTURE *texture);
HRESULT WINAPI ZDKMedia_Album_GetThumbnail(ZMEDIAITEM album, HTEXTURE *texture);
HRESULT WINAPI ZDKMedia_Album_HasAlbumArt(ZMEDIAITEM album, BOOL *hasArt);
HRESULT WINAPI ZDKMedia_Artist_GetAlbums(ZMEDIAITEM artist, HZMEDIALIST *albums);
HRESULT WINAPI ZDKMedia_Artist_GetSongs(ZMEDIAITEM artist, HZMEDIALIST *songs);
HRESULT WINAPI ZDKMedia_Genre_GetAlbums(ZMEDIAITEM genre, HZMEDIALIST *albums);
HRESULT WINAPI ZDKMedia_Genre_GetSongs(ZMEDIAITEM genre, HZMEDIALIST *songs);
HRESULT WINAPI ZDKMedia_Item_GetFilePath(ZMEDIAITEM item, LPWSTR path, DWORD charCount);
#ifdef ZUNE_HD
HRESULT WINAPI ZDKMedia_Item_GetMediaId(ZMEDIAITEM item, GUID *mediaId);
#endif
HRESULT WINAPI ZDKMedia_Item_GetName(ZMEDIAITEM item, LPWSTR name, DWORD charCount);
HRESULT WINAPI ZDKMedia_Item_GetType(ZMEDIAITEM item, ZDK_ITEM_TYPE *type);
HRESULT WINAPI ZDKMedia_Library_GetAlbums(HZMEDIALIST *albums);
HRESULT WINAPI ZDKMedia_Library_GetArtists(HZMEDIALIST *artists);
HRESULT WINAPI ZDKMedia_Library_GetGenres(HZMEDIALIST *genres);
HRESULT WINAPI ZDKMedia_Library_GetPictures(HZMEDIALIST *pictures);
HRESULT WINAPI ZDKMedia_Library_GetPlaylists(HZMEDIALIST *playlists);
HRESULT WINAPI ZDKMedia_Library_GetRootPictureAlbum(HZMEDIALIST *album);
HRESULT WINAPI ZDKMedia_Library_GetSongs(HZMEDIALIST *songs);
HRESULT WINAPI ZDKMedia_List_GetItemAtIndex(HZMEDIALIST list, int index, ZMEDIAITEM *item);
HRESULT WINAPI ZDKMedia_List_GetItemCount(HZMEDIALIST list, int *count);
HRESULT WINAPI ZDKMedia_List_GetType(HZMEDIALIST list, ZDK_ITEM_TYPE *type);
HRESULT WINAPI ZDKMedia_List_Release(HZMEDIALIST list);
HRESULT WINAPI ZDKMedia_PictureAlbum_GetChildAlbums(ZMEDIAITEM album, HZMEDIALIST *childrenAlbums);
HRESULT WINAPI ZDKMedia_PictureAlbum_GetParentAlbum(ZMEDIAITEM album, ZMEDIAITEM *parent);
HRESULT WINAPI ZDKMedia_PictureAlbum_GetPictures(ZMEDIAITEM album, HZMEDIALIST *pictures);
HRESULT WINAPI ZDKMedia_Picture_GetAlbum(ZMEDIAITEM picture, ZMEDIAITEM *album);
HRESULT WINAPI ZDKMedia_Picture_GetDate(ZMEDIAITEM picture, FILETIME *filetime);
HRESULT WINAPI ZDKMedia_Picture_GetDimensions(ZMEDIAITEM picture, int *width, int *height);
HRESULT WINAPI ZDKMedia_Picture_GetTexture(ZMEDIAITEM picture, HTEXTURE *texture);
HRESULT WINAPI ZDKMedia_Picture_GetThumbnail(ZMEDIAITEM picture, HTEXTURE *texture);
HRESULT WINAPI ZDKMedia_Playlist_GetDuration(ZMEDIAITEM playlist, int *duration);
HRESULT WINAPI ZDKMedia_Playlist_GetSongs(ZMEDIAITEM playlist, HZMEDIALIST *songs);
HRESULT WINAPI ZDKMedia_Song_GetAlbum(ZMEDIAITEM song, ZMEDIAITEM *album);
HRESULT WINAPI ZDKMedia_Song_GetArtist(ZMEDIAITEM song, ZMEDIAITEM *artist);
HRESULT WINAPI ZDKMedia_Song_GetDuration(ZMEDIAITEM song, int *duration);
HRESULT WINAPI ZDKMedia_Song_GetGenre(ZMEDIAITEM song, ZMEDIAITEM *genre);
HRESULT WINAPI ZDKMedia_Song_GetPlayCount(ZMEDIAITEM song, int *playCount);
HRESULT WINAPI ZDKMedia_Song_GetRating(ZMEDIAITEM song, int *rating);
HRESULT WINAPI ZDKMedia_Song_GetTrackNumber(ZMEDIAITEM song, int *trackNumber);
HRESULT WINAPI ZDKMedia_Song_IsDrmProtected(ZMEDIAITEM song, BOOL *restricted);

/* Media queue */

typedef enum
{
    MEDIA_STATE_STOPPED,
    MEDIA_STATE_PLAYING,
    MEDIA_STATE_PAUSED
} ZDK_MEDIA_STATE;

HRESULT WINAPI ZDKMedia_Queue_EnableViz(BOOL enable);
HRESULT WINAPI ZDKMedia_Queue_GetActiveSongIndex(int *songIndex);
HRESULT WINAPI ZDKMedia_Queue_GetPlayPosition(int *position);
HRESULT WINAPI ZDKMedia_Queue_GetPlayState(ZDK_MEDIA_STATE *state);
HRESULT WINAPI ZDKMedia_Queue_GetRepeat(BOOL *repeat);
HRESULT WINAPI ZDKMedia_Queue_GetShuffle(BOOL *shuffle);
HRESULT WINAPI ZDKMedia_Queue_GetSongAtIndex(int index, ZMEDIAITEM *song);
HRESULT WINAPI ZDKMedia_Queue_GetSongCount(int *songCount);
HRESULT WINAPI ZDKMedia_Queue_GetVizData(float frequencies[], int freqLen, float samples[], int sampleLen);
HRESULT WINAPI ZDKMedia_Queue_GetVolume(float *volume);
HRESULT WINAPI ZDKMedia_Queue_IsMuted(BOOL *muted);
HRESULT WINAPI ZDKMedia_Queue_IsVizEnabled(BOOL *enabled);
HRESULT WINAPI ZDKMedia_Queue_MoveNext();
HRESULT WINAPI ZDKMedia_Queue_MovePrev();
HRESULT WINAPI ZDKMedia_Queue_MoveTo(int songIndex);
HRESULT WINAPI ZDKMedia_Queue_Mute(BOOL mute);
HRESULT WINAPI ZDKMedia_Queue_PlaySong(ZMEDIAITEM song);
HRESULT WINAPI ZDKMedia_Queue_PlaySongFromFile(LPCWSTR name, LPCWSTR path, int duration);
#ifdef ZUNE_HD
HRESULT WINAPI ZDKMedia_Queue_PlaySongFromURL(LPCWSTR name, LPCWSTR url);
#endif
HRESULT WINAPI ZDKMedia_Queue_PlaySongList(HZMEDIALIST songList, int index);
HRESULT WINAPI ZDKMedia_Queue_SetPlayPosition(int position);
HRESULT WINAPI ZDKMedia_Queue_SetPlayState(ZDK_MEDIA_STATE state);
HRESULT WINAPI ZDKMedia_Queue_SetRepeat(BOOL repeat);
HRESULT WINAPI ZDKMedia_Queue_SetShuffle(BOOL shuffle);
HRESULT WINAPI ZDKMedia_Queue_SetVolume(float volume);

/* Video */

#ifdef ZUNE_HD
typedef enum
{
    VIDEO_PLAYBACK_STATE_1 = 1,
    VIDEO_PLAYBACK_STATE_2 = 2,
    VIDEO_PLAYBACK_STATE_3 = 3
} ZDK_VIDEO_PLAYBACK_STATE;

HRESULT WINAPI ZDKMedia_Video_GetPlayPosition(int *position);
HRESULT WINAPI ZDKMedia_Video_GetPlayState(ZDK_VIDEO_PLAYBACK_STATE *state);
HRESULT WINAPI ZDKMedia_Video_PlayVideoFromFile(LPCWSTR name, LPCWSTR path);
HRESULT WINAPI ZDKMedia_Video_SetPlayPosition(int position);
HRESULT WINAPI ZDKMedia_Video_SetPlayState(ZDK_VIDEO_PLAYBACK_STATE state);
#endif

/* Radio */

#ifdef ZUNE_HD
typedef struct
{
    DWORD Frequency;
    DWORD Subchannel;
    wchar_t Name[9];
} ZDK_RADIO_PRESET;

HRESULT WINAPI ZDKMedia_Radio_GetPreset(DWORD index, ZDK_RADIO_PRESET *preset);
HRESULT WINAPI ZDKMedia_Radio_GetPresetCount(DWORD *count);
HRESULT WINAPI ZDKMedia_Radio_Play(DWORD frequency, DWORD subchannel);
/* ZDKMedia_Radio_SetPreset */
#endif

#ifdef __cplusplus
}
#endif
#endif
