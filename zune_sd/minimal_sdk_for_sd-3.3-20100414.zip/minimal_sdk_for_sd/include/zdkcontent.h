﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zdkcontent.h => zdksystem.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZDKCONTENT_H
#define _ZDKCONTENT_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck
 *****************************************************************************/

/* Container management */

typedef enum
{
    CONTAINER_TYPE_RUNTIME     = 0x1,
    CONTAINER_TYPE_APPLICATION = 0x2,
    CONTAINER_TYPE_STORAGE     = 0x3
} ZDK_CONTAINER_TYPE;

typedef struct
{
    GUID UserGuid;
    GUID VirtualTitleId;
    ZDK_CONTAINER_TYPE ContainerType;
    wchar_t Name[40];
} ZDK_CONTAINER_INFO;

HRESULT WINAPI ZDKContent_Create(ZDK_CONTAINER_INFO *info, int w, int x, int y, int z);
HRESULT WINAPI ZDKContent_Mount(LPCWSTR mountPoint, ZDK_CONTAINER_INFO *info, BOOL flag);
HRESULT WINAPI ZDKContent_Unmount(LPCWSTR mountPoint);
HRESULT WINAPI ZDKContent_UnmountAll();
/* ZDKContent_Delete */
/* ZDKContent_Flush */
/* ZDKContent_SetMetaData */
/* ZDKContent_SetThumbnail */

/* Container enumeration */

/* ZDKContent_FindClose */
/* ZDKContent_FindFirst */
/* ZDKContent_FindNext */

#ifdef __cplusplus
}
#endif
#endif
