﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zcontent.h => zcontent.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZCONTENT_H
#define _ZCONTENT_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck, Netrix
 *****************************************************************************/

/* Container management */

#ifdef ZUNE_SD
typedef enum
{
    MOUNT_UNKNOWN_1 = 0x1,
    MOUNT_UNKNOWN_2 = 0x2,
    MOUNT_UNKNOWN_4 = 0x4
} ZCONTENT_MOUNT_FLAGS;

HRESULT WINAPI ZContent_Mount(LPCWSTR mountPoint, LPCWSTR container, ZCONTENT_MOUNT_FLAGS flags);
HRESULT WINAPI ZContent_Unmount(LPCWSTR mountPoint);
HRESULT WINAPI ZContent_UnmountAll();
/* ZContent_Create */
/* ZContent_Flush */
/* ZContent_GetInfo */
/* ZContent_SetMetaData */
/* ZContent_SetThumbnail */
#endif

#ifdef __cplusplus
}
#endif
#endif
