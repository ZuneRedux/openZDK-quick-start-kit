﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zdkinput.h => zdksystem.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZDKINPUT_H
#define _ZDKINPUT_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: Bman22, itsnotabigtruck, Netrix
 *****************************************************************************/

/* Touch/accelerometer data */

#ifdef ZUNE_HD
typedef struct
{
    int X;
    int Y;
    int Z;
} ZDK_ACCELEROMETER_STATE;

typedef struct
{
    unsigned int Id;
    float X;
    float Y;
    float Pressure;
} ZDK_TOUCH_LOCATION;

typedef struct
{
    int Count;
    ZDK_TOUCH_LOCATION Locations[4];
} ZDK_TOUCH_STATE;

typedef struct
{
    ZDK_TOUCH_STATE TouchState;
    ZDK_ACCELEROMETER_STATE AccelerometerState;
} ZDK_INPUT_STATE_HD;

typedef ZDK_INPUT_STATE_HD ZDK_INPUT_STATE;
#endif

/* D-pad/Zune pad data */

#ifdef ZUNE_SD
typedef enum
{
    BUTTON_UP         = 0x1,
    BUTTON_DOWN       = 0x2,
    BUTTON_LEFT       = 0x4,
    BUTTON_RIGHT      = 0x8,
    BUTTON_CENTER     = 0x10,
    BUTTON_TOUCH      = 0x20,
    BUTTON_ANY        = 0x40,
    BUTTON_PLAY_PAUSE = 0x80,
    BUTTON_BACK       = 0x100,
    BUTTON_HOLD       = 0x200
} ZDK_BUTTON_STATE;

typedef struct
{
    ZDK_BUTTON_STATE Buttons;
    short X;
    short Y;
    unsigned int PacketNumber;
} ZDK_INPUT_STATE_SD;

typedef ZDK_INPUT_STATE_SD ZDK_INPUT_STATE;
#endif

/* Input functions */

#ifdef ZUNE_SD
HRESULT WINAPI ZDKInput_GetCapabilities(ZDK_INPUT_STATE *capabilities);
#endif
HRESULT WINAPI ZDKInput_GetState(ZDK_INPUT_STATE *state);
HRESULT WINAPI ZDKInput_Initialize();
HRESULT WINAPI ZDKInput_Shutdown();
#ifdef ZUNE_HD
/* ZDKInput_GetNextInputMessage */
/* ZDKInput_EnableInputMessages */
#endif

#ifdef __cplusplus
}
#endif
#endif
