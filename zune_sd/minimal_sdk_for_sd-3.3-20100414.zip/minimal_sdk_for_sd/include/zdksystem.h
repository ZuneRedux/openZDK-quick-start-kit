﻿/*  _____                         ________   ____    __  __
 * /\  __`\                      /\_____  \ /\  _`\ /\ \/\ \
 * \ \ \/\ \  _____     __    ___\/____//'/'\ \ \/\ \ \ \/'/'
 *  \ \ \ \ \/\ '__`\ /'__`\/' _ `\   //'/'  \ \ \ \ \ \ , <
 *   \ \ \_\ \ \ \L\ \\  __//\ \/\ \ //'/'___ \ \ \_\ \ \ \\`\
 *    \ \_____\ \ ,__/ \____\ \_\ \_\/\_______\\ \____/\ \_\ \_\
 *     \/_____/\ \ \/ \/____/\/_/\/_/\/_______/ \/___/  \/_/\/_/
 *              \ \_\
 *               \/_/ OpenZDK Release 1 | 2010-04-14
 *
 * zdksystem.h => zdksystem.lib
 * Copyright (c) 2010 (contributors).
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#ifndef _ZDKSYSTEM_H
#define _ZDKSYSTEM_H
#include <windows.h>
#ifdef __cplusplus
extern "C" {
#endif
#if !defined(ZUNE_SD) && !defined(ZUNE_HD)
#error ZUNE_HD or ZUNE_SD must be defined
#endif

/*****************************************************************************
 Report inaccurate or missing function signatures at http://zunedevwiki.org/
 Information contributed by: itsnotabigtruck
 *****************************************************************************/

/* Browser/search */

#ifdef ZUNE_HD
HRESULT WINAPI ZDKSystem_LaunchBrowser(LPCWSTR url);
HRESULT WINAPI ZDKSystem_LaunchMarketplaceSearch(LPCWSTR query);
#endif

/* Display configuration */

#ifdef ZUNE_HD
typedef enum
{
    ORIENTATION_0 = 0,
    ORIENTATION_180 = 1,
    ORIENTATION_270 = 2,
    ORIENTATION_90 = 3,
    ORIENTATION_0_2 = 4
} ZDK_ORIENTATION;

HRESULT WINAPI ZDKSystem_GetScreenDimensions(DWORD *screenWidth, DWORD *screenHeight);
HRESULT WINAPI ZDKSystem_SetOrientation(ZDK_ORIENTATION orientation);
#endif

/* Guide */

typedef enum
{
    GUIDE_MODE_MEDIA_SELECTOR  = 1,
    GUIDE_MODE_WIRELESS_PROMPT = 2
} ZDK_GUIDE_MODE;

HRESULT WINAPI ZDKSystem_IsShowingGuide(BOOL *guideVisible);
HRESULT WINAPI ZDKSystem_SetTitleName(LPCWSTR titleName, DWORD length);
HRESULT WINAPI ZDKSystem_ShowGuide(ZDK_GUIDE_MODE mode);

/* Hash algorithms */

#ifdef ZUNE_HD
/* ZDKSystem_CloseHash */
/* ZDKSystem_OpenHash */
/* ZDKSystem_UpdateHash */
#endif

/* Interop modules */

#ifdef ZUNE_HD
/* ZuneExtensions_BeginShutdown */
/* ZuneExtensions_RegisterInteropModule */
/* ZuneExtensions_UnregisterInteropModule */
#endif

/* Keyboard input */

#ifdef ZUNE_HD
typedef enum
{
    KEYBOARD_STATE_CLOSED    = 0,
    KEYBOARD_STATE_IDLE      = 1,
    KEYBOARD_STATE_EDITED    = 2,
    KEYBOARD_STATE_DISMISSED = 3
} ZDK_KEYBOARD_STATE;

#define KEYBOARD_MULTILINE    0x1  /* 0x2, 0x4, and 0x20 unknown */
#define KEYBOARD_PASSWORD     0x8
#define KEYBOARD_URL          0x10
#define KEYBOARD_AUTOCOMPLETE 0x40

HRESULT WINAPI ZDKSystem_CloseKeyboard();
HRESULT WINAPI ZDKSystem_GetKeyboardBufferText(LPWSTR text, DWORD length);
ZDK_KEYBOARD_STATE WINAPI ZDKSystem_GetKeyboardState();
HRESULT WINAPI ZDKSystem_SetKeyboardBufferText(LPCWSTR text);
/* ZDKSystem_SetKeyboardSuggestions */
HRESULT WINAPI ZDKSystem_ShowKeyboard(LPCWSTR defaultValue, LPCWSTR closeLabel, DWORD flags);
#endif

/* Loading animation */

HRESULT WINAPI ZDKSystem_ShowSplashScreen(BOOL visible);

/* Memory management */

HANDLE WINAPI ZDKSystem_GetProcessHeap();
/* ZDKSystem_HeapAlloc */
/* ZDKSystem_HeapCompact */
/* ZDKSystem_HeapCreate */
/* ZDKSystem_HeapDestroy */
/* ZDKSystem_HeapFree */
/* ZDKSystem_HeapReAlloc */
/* ZDKSystem_HeapSize */
/* ZDKSystem_MapFile */
/* ZDKSystem_UnmapFile */
/* ZDKSystem_VirtualAlloc */
/* ZDKSystem_VirtualAllocGetSize */
/* ZDKSystem_VirtualFree */

/* Message boxes */

#ifdef ZUNE_HD
typedef enum
{
    MESSAGEBOX_TYPE_AUTOCLOSE = 1,
    MESSAGEBOX_TYPE_MANUALCLOSE = 2,
    MESSAGEBOX_TYPE_OK = 3,
    MESSAGEBOX_TYPE_OK_CANCEL = 4,
    MESSAGEBOX_TYPE_OK_CANCEL_2 = 5,
    MESSAGEBOX_TYPE_YES_NO = 6,
    MESSAGEBOX_TYPE_YES_NO_2 = 7,
} ZDK_MESSAGEBOX_TYPE;

typedef enum
{
    MESSAGEBOX_STATE_CLOSED     = 0,
    MESSAGEBOX_STATE_ACTIVE     = 1,
    MESSAGEBOX_STATE_AUTOCLOSED = 2,
    MESSAGEBOX_STATE_OK         = 3,
    MESSAGEBOX_STATE_CANCEL     = 4,
    MESSAGEBOX_STATE_YES        = 5,
    MESSAGEBOX_STATE_NO         = 6
} ZDK_MESSAGEBOX_STATE;

HRESULT WINAPI ZDKSystem_CloseMessageBox();
ZDK_MESSAGEBOX_STATE WINAPI ZDKSystem_GetMessageBoxState();
HRESULT WINAPI ZDKSystem_ShowMessageBox(LPCWSTR message, ZDK_MESSAGEBOX_TYPE type);
#endif

/* Notifications */

DECLARE_HANDLE(HNOTIFICATION);

HRESULT WINAPI ZDKSystem_CloseNotifyHandle(HNOTIFICATION handle);
/* ZDKSystem_GetNextNotification */
HRESULT WINAPI ZDKSystem_GetNotifyHandle(HNOTIFICATION *handle);

/* Power state */

typedef enum
{
    POWER_STATUS_CHARGING    = 0x1,
    POWER_STATUS_DISCHARGING = 0x2,
    POWER_STATUS_CRITICAL    = 0x4,
    POWER_STATUS_LOW         = 0x8,
    POWER_STATUS_HIGH        = 0x10
} ZDK_POWER_STATUS;

HRESULT WINAPI ZDKSystem_GetPowerState(ZDK_POWER_STATUS *status, float *percentage);

/* System information */

#ifdef ZUNE_HD
/* ZDKSystem_GetDeviceId */
#endif
/* ZDKSystem_GetDiskInfo */

/* System lock */

HRESULT WINAPI ZDKSystem_GetLockswitchState(BOOL *state);
#ifdef ZUNE_HD
/* ZDKSystem_GetUnlockChallenge */
/* ZDKSystem_SetUnlockResponse */
#endif

/* Time */

#ifdef ZUNE_HD
HRESULT WINAPI ZDKSystem_GetLocalTimeOffset(LONG *minutes);

extern __inline HRESULT ZDKSystem_GetLocalTime(LPFILETIME lpFileTime)
{
    ULARGE_INTEGER lgint = { 0 };
    LONG offset;
    HRESULT hr;

    if (!lpFileTime)
        return E_POINTER;
    hr = ZDKSystem_GetLocalTimeOffset(&offset);
    if (SUCCEEDED(hr))
    {
        GetCurrentFT((FILETIME *)&lgint.u);
        lgint.QuadPart += offset * 600000000LL;
        *lpFileTime = *(FILETIME *)&lgint.u;
    }
    return hr;
}
#endif

/* User activity */

#ifdef ZUNE_HD
HRESULT WINAPI ZDKSystem_SignalUserActivity();
HRESULT WINAPI ZDKSystem_SignalUserActivityEx(BOOL flag);
#endif

/* User information */

typedef LONGLONG XUID;

HRESULT WINAPI ZDKSystem_GetUserGuid(GUID *userGuid);
HRESULT WINAPI ZDKSystem_GetUserName(LPWSTR userName, DWORD length);
XUID WINAPI ZDKSystem_UserGuidToXuid(GUID *userGuid);

#ifdef __cplusplus
}
#endif
#endif
