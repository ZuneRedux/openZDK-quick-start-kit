varying vec4 col_var;
void main()
{
    gl_FragColor = col_var;
}