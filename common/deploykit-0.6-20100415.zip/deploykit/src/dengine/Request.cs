﻿/* Request.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    sealed class Request : Message
    {
        object[] _values;
        ActionDefinition _definition;

        public Request(ActionDefinition definition)
            : base(MessageType.Request)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");
            _definition = definition;
            _values = new object[definition.Parameters.Count];
        }
        public ActionDefinition Definition
        {
            get { return _definition; }
        }
        public Request Argument(string name, object value)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException("A parameter name must be specified", "name");
            Parameter param = null;
            int index;
            for (index = 0; index < _definition.Parameters.Count; ++index)
            {
                if (_definition.Parameters[index].Name == name)
                {
                    param = _definition.Parameters[index];
                    break;
                }
            }
            if (param == null)
                throw new ArgumentException("The specified parameter does not exist", "name");
            switch (param.Type)
            {
                case ParameterType.Blob:
                    _values[index] = (Stream)value;
                    break;
                case ParameterType.Boolean:
                    _values[index] = Convert.ToBoolean(value);
                    break;
                case ParameterType.Byte:
                    _values[index] = Convert.ToByte(value);
                    break;
                case ParameterType.DateTime:
                    _values[index] = Convert.ToDateTime(value);
                    break;
                case ParameterType.Double:
                    _values[index] = Convert.ToDouble(value);
                    break;
                case ParameterType.Guid:
                    _values[index] = new Guid(Convert.ToString(value));
                    break;
                case ParameterType.Int16:
                    _values[index] = Convert.ToInt16(value);
                    break;
                case ParameterType.Int32:
                    _values[index] = Convert.ToInt32(value);
                    break;
                case ParameterType.Int64:
                    _values[index] = Convert.ToInt64(value);
                    break;
                case ParameterType.Single:
                    _values[index] = Convert.ToSingle(value);
                    break;
                case ParameterType.String:
                    _values[index] = Convert.ToString(value);
                    break;
                default:
                    throw new ArgumentException("The specified parameter is of unsupported type", "name");
            }
            return this;
        }
        public Stream[] GetDelayedParameters()
        {
            List<Stream> dps = new List<Stream>();
            for (int i = 0; i < _values.Length; ++i)
            {
                Stream s = _values[i] as Stream;
                if (s != null) dps.Add(s);
            }
            return dps.ToArray();
        }
        public static Request DeserializePayload(Stream stream)
        {
            throw new InvalidOperationException("Requests cannot be transmitted from the device side");
        }
        protected override void SerializePayload(Stream stream)
        {
            for (int i = 0; i < _values.Length; ++i)
                if (_values[i] == null)
                    throw new InvalidOperationException("The current request does not contain values for all of the parameters of the associated verb");
            BinaryWriter bw = new BinaryWriter(stream, Encoding.Unicode);
            bw.Write(_definition.Name);
            bw.Write((byte)_definition.Parameters.Count);
            for (byte i = 0; i < _values.Length; ++i)
            {
                Parameter param = _definition.Parameters[i];
                bw.Write(param.Name);
                bw.Write((byte)param.Type);
                switch (param.Type)
                {
                    case ParameterType.Blob:
                        bw.Write((byte)(i + 1));
                        bw.Write((int)(((Stream)_values[i]).Length));
                        break;
                    case ParameterType.Boolean:
                        bw.Write((bool)_values[i]);
                        break;
                    case ParameterType.Byte:
                        bw.Write((byte)_values[i]);
                        break;
                    case ParameterType.DateTime:
                        bw.Write(((DateTime)_values[i]).Ticks);
                        break;
                    case ParameterType.Double:
                        bw.Write((double)_values[i]);
                        break;
                    case ParameterType.Guid:
                        bw.Write(((Guid)_values[i]).ToByteArray());
                        break;
                    case ParameterType.Int16:
                        bw.Write((short)_values[i]);
                        break;
                    case ParameterType.Int32:
                        bw.Write((int)_values[i]);
                        break;
                    case ParameterType.Int64:
                        bw.Write((long)_values[i]);
                        break;
                    case ParameterType.Single:
                        bw.Write((float)_values[i]);
                        break;
                    case ParameterType.String:
                        bw.Write((string)_values[i] ?? string.Empty);
                        break;
                }
            }
            bw.Flush();
        }
    }
}
