﻿/* Message.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    abstract class Message
    {
        static readonly byte[] _magicValue = new byte[] { 0x58, 0x4e, 0x41, 0x46, 0x54, 0x57 }; // XNAFTW

        MessageType _type;

        protected Message(MessageType type)
        {
            if (!Enum.IsDefined(typeof(MessageType), type)) throw new InvalidEnumArgumentException("type", (int)type, typeof(MessageType));
            _type = type;
        }
        public MessageType Type
        {
            get { return _type; }
        }
        public static Message Deserialize(Stream stream)
        {
            BinaryReader br = new BinaryReader(stream, Encoding.Unicode);
            // check the magic
            byte[] magic = br.ReadBytes(_magicValue.Length);
            for (int i = 0; i < magic.Length; ++i)
                if (magic[i] != _magicValue[i]) throw new InvalidDataException("The magic value of the device response was incorrect");
            // check the packet type
            MessageType packettype = (MessageType)br.ReadByte();
            switch (packettype)
            {
                case MessageType.Request:
                    return Request.DeserializePayload(stream);
                case MessageType.Response:
                    return Response.DeserializePayload(stream);
                case MessageType.Schema:
                    return Schema.DeserializePayload(stream);
                default:
                    throw new InvalidDataException("A message of unknown type was received");
            }
        }
        public static T Deserialize<T>(Stream stream)
            where T : Message
        {
            T msg = Deserialize(stream) as T;
            if (msg == null)
                throw new InvalidDataException("A message of the expected type was not received");
            return msg;
        }
        public void Serialize(Stream stream)
        {
            BinaryWriter bw = new BinaryWriter(stream, Encoding.Unicode);
            bw.Write(_magicValue);
            bw.Write((byte)Type);
            SerializePayload(stream);
        }
        protected abstract void SerializePayload(Stream stream);
    }
}
