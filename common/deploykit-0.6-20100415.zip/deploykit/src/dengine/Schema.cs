﻿/* Schema.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    sealed class Schema : Message
    {
        List<ActionDefinition> _actions = new List<ActionDefinition>();

        Schema()
            : base(MessageType.Schema)
        {
        }
        public static Schema DeserializePayload(Stream stream)
        {
            Schema sc = new Schema();
            BinaryReader br = new BinaryReader(stream, Encoding.Unicode);
            // read the verbs
            byte verbcount = br.ReadByte();
            for (int i = 0; i < verbcount; ++i)
            {
                string verbname = br.ReadString();
                byte paramcount = br.ReadByte();
                List<Parameter> parms = new List<Parameter>(paramcount);
                for (int j = 0; j < paramcount; ++j)
                {
                    string paramname = br.ReadString();
                    ParameterType type = (ParameterType)br.ReadByte();
                    parms.Add(new Parameter(paramname, type));
                }
                sc._actions.Add(new ActionDefinition(verbname, parms));
            }
            return sc;
        }
        protected override void SerializePayload(Stream stream)
        {
            throw new InvalidOperationException("Schemata cannot be transmitted from the host side");
        }
        public IList<ActionDefinition> Actions
        {
            get { return _actions; }
        }
    }
}
