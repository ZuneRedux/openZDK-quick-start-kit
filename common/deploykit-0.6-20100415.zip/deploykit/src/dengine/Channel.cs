﻿/* Channel.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    public sealed class Channel : IDisposable
    {
        public static readonly Guid ApplicationLaunchChannelType     = new Guid("A40D216D-FBD3-40d4-B852-DE77478C1475");
        public static readonly Guid RuntimeDeploymentChannelType     = new Guid("30D0E81E-D272-4735-ABD3-918ADAD29FD3");
        public static readonly Guid ApplicationDeploymentChannelType = new Guid("AA3C2881-4EB9-4af6-8137-635C2E64CE4A");

        static readonly ActionDefinition _createChannelVerb = new ActionDefinition("CreateChannel", new Parameter[] {
            new Parameter("ChannelId", ParameterType.Guid)
        });

        Endpoint _endpoint;
        Stream _backingStream;
        Guid _channelType;
        int _id;
        ActionImplementationCollection _actions;

        public Channel(Endpoint endpoint, Guid channelType)
        {
            // handle args
            if (endpoint == null)
                throw new ArgumentNullException("device");
            _endpoint = endpoint;
            _channelType = channelType;
            // broker required channel type
            using (_backingStream = new PacketStream(endpoint, "XnaChannelBroker", 5000))
            {
                Request req = new Request(_createChannelVerb);
                req.Argument("ChannelId", channelType);
                _id = (int)Invoke(req).Value;
            }
            // open "real" channel
            _backingStream = new PacketStream(endpoint, "XNACHAN" + _id.ToString(CultureInfo.InvariantCulture), 5000);
            // receive channel schema
            _actions = new ActionImplementationCollection();
            foreach (ActionDefinition def in Message.Deserialize<Schema>(_backingStream).Actions)
                _actions.Add(new ActionImplementation(def, this));
        }
        public KeyedCollection<string, ActionImplementation> Actions
        {
            get { return _actions; }
        }
        public int ChannelId
        {
            get { return _id; }
        }
        public Guid ChannelType
        {
            get { return _channelType; }
        }
        public void Close()
        {
            if (_backingStream != null)
                _backingStream.Close();
        }
        void IDisposable.Dispose()
        {
            Close();
        }
        internal Response Invoke(Request request)
        {
            request.Serialize(_backingStream);
            Response resp = Response.Deserialize<Response>(_backingStream);
            if (resp.RequiresDelayedParameterFulfillment)
            {
                Stream[] dps = request.GetDelayedParameters();
                int i = 0;
                BinaryWriter bw = new BinaryWriter(_backingStream);
                while (resp.RequiresDelayedParameterFulfillment)
                {
                    if (i >= dps.Length) throw new InvalidDataException("No stream is available to service the delayed parameter request");
                    Stream s = dps[i];
                    long len = s.Length;
                    if (len > 0x7FFFFFFFL) throw new InvalidDataException("Delayed parameter streams cannot be longer than 2 GB");
                    while (len > 0)
                    {
                        int count = len > 0x1FFFBL ? 0x1FFFB : (int)len; // the Zune will choke with chunks > 128 KiB
                        byte[] buf = new byte[count];
                        len -= (count = s.Read(buf, 0, count));
                        if (count == 0)
                            throw new InvalidDataException("The end of the stream was unexpectedly reached");
                        bw.Write(false);
                        bw.Write(count);
                        bw.Write(buf, 0, count);
                        bw.Flush();
                    }
                    resp = Message.Deserialize<Response>(_backingStream);
                    ++i;
                }
            }
            return resp;
        }
    }
}
