﻿/* ActionImplementation.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    public sealed class ActionImplementation : IAction
    {
        ActionDefinition _definition;
        Channel _target;

        internal ActionImplementation(ActionDefinition definition, Channel target)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");
            if (target == null)
                throw new ArgumentNullException("target");
            _definition = definition;
            _target = target;
        }
        public string Name
        {
            get { return _definition.Name; }
        }
        public IList<Parameter> Parameters
        {
            get { return _definition.Parameters; }
        }
        public object Invoke(params object[] arguments)
        {
            if (arguments == null)
                throw new ArgumentNullException("arguments");
            if (_definition.Parameters.Count != arguments.Length)
                throw new ArgumentException("An incorrect number of arguments was supplied", "arguments");
            Request req = new Request(_definition);
            for (int i = 0; i < _definition.Parameters.Count; ++i)
            {
                Parameter param = _definition.Parameters[i];
                try
                {
                    req.Argument(param.Name, arguments[i]);
                }
                catch (Exception ex)
                {
                    throw new ArgumentException(string.Format("The argument supplied for formal parameter '{0}' to verb '{1}' is not of correct type", param.Name, _definition.Name), "arguments", ex);
                }
            }
            return _target.Invoke(req).Value;
        }
        public override string ToString()
        {
            return _definition.Name;
        }
    }
}
