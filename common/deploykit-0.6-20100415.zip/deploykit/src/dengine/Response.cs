﻿/* Response.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.IO;
using System.Text;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    sealed class Response : Message
    {
        object _value;
        bool _requiresDelayedParameterFulfillment;

        Response()
            : base(MessageType.Response)
        {
        }
        public bool RequiresDelayedParameterFulfillment
        {
            get { return _requiresDelayedParameterFulfillment; }
        }
        public object Value
        {
            get { return _value; }
        }
        public static Response DeserializePayload(Stream stream)
        {
            try
            {
                Response resp = new Response();
                BinaryReader br = new BinaryReader(stream, Encoding.Unicode);
                // check if there was a fault
                bool faulted = br.ReadBoolean();
                // check whether this response requires delayed param fulfillment
                resp._requiresDelayedParameterFulfillment = br.ReadBoolean();
                // read fault info and throw up if necessary
                if (faulted)
                {
                    int id = br.ReadInt32();
                    string message = br.ReadString();
                    throw new DeviceFaultException(id, message);
                }
                // read the value - responses use the same encoding as parameters
                ParameterType type = (ParameterType)br.ReadByte();
                if (!Enum.IsDefined(typeof(ParameterType), type)) throw new InvalidDataException("The response contains an unrecognized parameter type");
                switch (type)
                {
                    case ParameterType.Blob:
                        throw new NotSupportedException("BLOBs are not supported in responses");
                    case ParameterType.Boolean:
                        resp._value = br.ReadBoolean();
                        break;
                    case ParameterType.Byte:
                        resp._value = br.ReadByte();
                        break;
                    case ParameterType.DateTime:
                        resp._value = new DateTime(br.ReadInt64());
                        break;
                    case ParameterType.Double:
                        resp._value = br.ReadDouble();
                        break;
                    case ParameterType.Guid:
                        resp._value = new Guid(br.ReadBytes(16));
                        break;
                    case ParameterType.Int16:
                        resp._value = br.ReadInt16();
                        break;
                    case ParameterType.Int32:
                        resp._value = br.ReadInt32();
                        break;
                    case ParameterType.Int64:
                        resp._value = br.ReadInt64();
                        break;
                    case ParameterType.Single:
                        resp._value = br.ReadSingle();
                        break;
                    case ParameterType.String:
                        resp._value = br.ReadString();
                        break;
                }
                return resp;
            }
            catch (DeviceFaultException)
            {
                throw;
            }
            catch (InvalidDataException)
            {
                throw;
            }
            catch (NotSupportedException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new InvalidDataException("The specified response is invalid", ex);
            }
        }
        protected override void SerializePayload(Stream stream)
        {
            throw new NotImplementedException("Responses cannot be serialized from the host side");
        }
    }
}
