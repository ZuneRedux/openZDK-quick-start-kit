﻿/* PacketStream.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.IO;
using Microsoft.Xna.RemoteServices;
using Microsoft.Xna.RemoteServices.Interop;

namespace ZuneBoards.DevelopmentFront.DeployKit.Engine
{
    sealed class PacketStream : Stream
    {
        /* Known service IDs
         * 
         * {7F7534A1-293D-495E-88DA-F1EA984EF075} Profiler
         * {92C8EE24-92DF-4cb5-99C2-B4C7068528E9} Console
         * {7ABBE0D5-B437-42ca-B57B-CEED61680E4F} Debugger
         * {2B80CE0A-7119-413e-BA6F-E451AC9382AF} Performance monitor
         * {754BD393-556F-4a33-8541-BC009FFE979E} Sampling profiler
         * {D8F4AE7C-581B-4898-97C0-F08EBC001D20} Error popup suppression
         * {BC66BB72-DE63-4b31-956E-B3878CE9F5D2} Test target
         * {D0F348D2-9667-4ef2-B078-BF94077177FD} Trace
         * XnaChannelBroker                       Deployment/launch channel broker
         * XnaScreenshotService                   Screenshot acquisition
         * XNACHANx                               Brokered channel (x = returned channel ID)
         */

        ServiceClient _sc;
        string _serviceId;
        int _streamId;
        int _writeTimeout = 10000;
        int _readTimeout = 10000;
        MemoryStream _writeBuffer = new MemoryStream();

        public PacketStream(Endpoint endpoint, string serviceId, int connectTimeout)
        {
            if (endpoint == null)
                throw new ArgumentNullException("device");
            if (string.IsNullOrEmpty("serviceId"))
                throw new ArgumentException("A service ID must be specified", "serviceId");
            _serviceId = serviceId;
            _sc = ServiceClient.CreateInstance(HostType.Zune);
            _sc.Connect(endpoint.Name, (int)HostType.Zune, serviceId, connectTimeout);
            _streamId = _sc.StreamId;
        }
        public override bool CanRead
        {
            get { return true; }
        }
        public override bool CanSeek
        {
            get { return false; }
        }
        public override bool CanWrite
        {
            get { return true; }
        }
        public string ServiceId
        {
            get { return _serviceId; }
        }
        public int StreamId
        {
            get { return _streamId; }
        }
        public override void Flush()
        {
            if (_writeBuffer.Length != 0)
            {
                _sc.Write(_writeBuffer.ToArray(), _writeTimeout);
                _writeBuffer.SetLength(0);
            }
        }
        public override long Length
        {
            get { throw new NotSupportedException(); }
        }
        public override long Position
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }
        public override int ReadTimeout
        {
            get { return _readTimeout; }
            set { _readTimeout = value; }
        }
        public override int WriteTimeout
        {
            get { return _writeTimeout; }
            set { _writeTimeout = value; }
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            byte[] blob;
            _sc.Read(out blob, count, _readTimeout);
            Buffer.BlockCopy(blob, 0, buffer, offset, count);
            return count;
        }
        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }
        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }
        public override void Write(byte[] buffer, int offset, int count)
        {
            _writeBuffer.Write(buffer, offset, count);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
                GC.SuppressFinalize(this);
            try
            {
                _sc.Dispose();
            }
            catch
            {
            }
        }
        ~PacketStream()
        {
            Dispose(false);
        }
    }
}
