﻿/* RuntimeContainer.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using Microsoft.Win32;
using ZuneBoards.DevelopmentFront.DeployKit.Engine;

namespace ZuneBoards.DevelopmentFront.DeployKit.Deployment
{
    sealed class RuntimeContainer : Container
    {
        uint _revision;
        string _runtimeToken;

        public uint Revision
        {
            get { return _revision; }
            set { _revision = value; }
        }
        public string RuntimeToken
        {
            get { return _runtimeToken; }
            set { _runtimeToken = value; }
        }
        public override void Deploy(Endpoint target)
        {
            try
            {
                Validate();
                if (DeploymentDisposition != DeploymentDisposition.Never)
                {
                    base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.VerifyingContainer, null, UserState));
                    using (Channel channel = new Channel(target, Channel.RuntimeDeploymentChannelType))
                    {
                        if (DeploymentDisposition == DeploymentDisposition.Always ||
                            !(bool)channel.Actions["IsRuntimeAvailable"].Invoke(_runtimeToken, _revision))
                        {
                            // open container
                            base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.StartDeployment, null, UserState));
                            channel.Actions["OpenRuntimeContainer"].Invoke(_runtimeToken, _revision);
                            // deploy files
                            DeployContent(channel, Contents);
                            // close container
                            base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.EndDeployment, null, UserState));
                            channel.Actions["CloseRuntimeContainer"].Invoke();
                        }
                    }
                }
                base.OnDeployCompleted(new AsyncCompletedEventArgs(null, false, UserState));
            }
            catch (Exception ex)
            {
                base.OnDeployCompleted(new AsyncCompletedEventArgs(ex, false, UserState));
            }
        }
        void DeployContent(Channel deployChannel, IList<ContainerItem> items)
        {
            foreach (ContainerItem item in items)
            {
                if (item is ContainerDirectory)
                {
                    ContainerDirectory dir = (ContainerDirectory)item;
                    DeployContent(deployChannel, dir.Items);
                }
            }
            foreach (ContainerItem item in items)
            {
                if (item is ContainerFile)
                {
                    ContainerFile file = (ContainerFile)item;
                    using (FileStream fs = File.OpenRead(file.SourcePath))
                    {
                        deployChannel.Actions["PutFileInContainer"].Invoke(file.RelativePath, fs);
                        base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.DeployingFile, file, UserState));
                    }
                }
            }
        }
        public static IList<RuntimeContainer> GetInstalledRuntimes(string platform)
        {
            if (string.IsNullOrEmpty(platform))
                throw new ArgumentException("A platform must be specified", "platform");
            if (platform.Contains(@"\"))
                throw new ArgumentException("The specified platform name is invalid", "platform");
            List<RuntimeContainer> runtimes = new List<RuntimeContainer>();
            RegistryKey root = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\XNA\Game Studio\DeployableRuntimes\" + platform);
            if (root == null)
                return runtimes;
            using (root)
            {
                string[] tokens = root.GetSubKeyNames();
                foreach (string token in tokens)
                {
                    string adjustedToken = token;
                    if (adjustedToken == "Zune.v3.1")
                        adjustedToken = "Zune.v4.0.Beta";
                    using (RegistryKey tokenKey = root.OpenSubKey(token))
                    {
                        string[] labels = tokenKey.GetSubKeyNames();
                        foreach (string label in labels)
                        {
                            try
                            {
                                using (RegistryKey labelKey = tokenKey.OpenSubKey(label))
                                {
                                    RuntimeContainer container = new RuntimeContainer();
                                    container.Revision = (uint)(int)labelKey.GetValue("Version");
                                    container.RuntimeToken = adjustedToken;
                                    container.DeploymentDisposition = DeploymentDisposition.Auto;
                                    container.Contents.Import((string)labelKey.GetValue("Path"));
                                    runtimes.Add(container);
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                }
            }
            return runtimes;
        }
        void Validate()
        {
            if (string.IsNullOrEmpty(_runtimeToken))
                throw new InvalidOperationException("A runtime token must be set before the container can be deployed");
        }
    }
}
