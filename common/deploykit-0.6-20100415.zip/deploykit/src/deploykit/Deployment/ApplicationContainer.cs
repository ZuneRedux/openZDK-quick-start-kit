﻿/* ApplicationContainer.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using ZuneBoards.DevelopmentFront.DeployKit.Engine;

namespace ZuneBoards.DevelopmentFront.DeployKit.Deployment
{
    sealed class ApplicationContainer : Container
    {
        string _displayName;
        string _description;
        Guid _virtualApplicationId;
        ContainerFile _startupAssembly;
        string _thumbnailPath;
        LaunchDisposition _launchDisposition;
        ApplicationCompatibility _compatibility;
        RuntimeContainer _targetRuntime;

        public string DisplayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public Guid VirtualApplicationId
        {
            get { return _virtualApplicationId; }
            set { _virtualApplicationId = value; }
        }
        public ContainerFile StartupAssembly
        {
            get { return _startupAssembly; }
            set { _startupAssembly = value; }
        }
        public string ThumbnailPath
        {
            get { return _thumbnailPath; }
            set { _thumbnailPath = value; }
        }
        public LaunchDisposition LaunchDisposition
        {
            get { return _launchDisposition; }
            set { _launchDisposition = value; }
        }
        public ApplicationCompatibility Compatibility
        {
            get { return _compatibility; }
            set { _compatibility = value; }
        }
        public RuntimeContainer TargetRuntime
        {
            get { return _targetRuntime; }
            set { _targetRuntime = value; }
        }
        public override void Deploy(Endpoint target)
        {
            try
            {
                Validate();
                if (DeploymentDisposition != DeploymentDisposition.Never)
                {
                    base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.StartDeployment, null, UserState));
                    using (Channel channel = new Channel(target, Channel.ApplicationDeploymentChannelType))
                    {
                        // open container
                        channel.Actions["OpenGameContainer"].Invoke(_virtualApplicationId, _displayName);
                        // deploy files
                        DeployContent(channel, Contents);
                        // set metadata and thumbnail
                        base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.EndDeployment, null, UserState));
                        if (_thumbnailPath != null)
                        {
                            using (FileStream fs = File.OpenRead(_thumbnailPath))
                            {
                                channel.Actions["PutThumbnailInContainer"].Invoke(fs);
                            }
                        }
                        channel.Actions["PutGamePropertiesEx"].Invoke(_virtualApplicationId,
                                                                      _displayName,
                                                                      _description,
                                                                      _startupAssembly.RelativePath,
                                                                      _targetRuntime.RuntimeToken);
                        // close container
                        channel.Actions["CloseGameContainer"].Invoke();
                    }
                }
                if (LaunchDisposition != LaunchDisposition.None)
                {
                    using (Channel channel = new Channel(target, Channel.ApplicationLaunchChannelType))
                    {
                        base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.LaunchingApplication, null, UserState));
                        channel.Actions["LaunchTestMode"].Invoke(_virtualApplicationId.ToString("N"), null, true);
                        if (LaunchDisposition == LaunchDisposition.Blocking)
                        {
                            base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.WaitingForApplication, null, UserState));
                            do
                            {
                                Thread.Sleep(1000);
                            } while ((bool)channel.Actions["IsTitleRunning"].Invoke());
                        }
                    }
                }
                base.OnDeployCompleted(new AsyncCompletedEventArgs(null, false, UserState));
            }
            catch (Exception ex)
            {
                base.OnDeployCompleted(new AsyncCompletedEventArgs(ex, false, UserState));
            }
        }
        void DeployContent(Channel deployChannel, IList<ContainerItem> items)
        {
            foreach (ContainerItem item in items)
            {
                if (item is ContainerDirectory)
                {
                    ContainerDirectory dir = (ContainerDirectory)item;
                    DeployContent(deployChannel, dir.Items);
                }
            }
            foreach (ContainerItem item in items)
            {
                if (item is ContainerFile)
                {
                    ContainerFile file = (ContainerFile)item;
                    using (FileStream fs = File.OpenRead(file.SourcePath))
                    {
                        deployChannel.Actions["PutFileInContainer"].Invoke(file.RelativePath, fs);
                        base.OnDeployProgressChanged(new DeployProgressChangedEventArgs(this, DeploymentTask.DeployingFile, file, UserState));
                    }
                }
            }
        }
        void Validate()
        {
            if (string.IsNullOrEmpty(_displayName))
                throw new InvalidOperationException("A display name must be set before the container can be deployed");
            if (_startupAssembly == null)
                throw new InvalidOperationException("A startup assembly must be set before the container can be deployed");
            if (_thumbnailPath != null && !File.Exists(_thumbnailPath))
                throw new InvalidOperationException("If a thumbnail image path is set, it must specify a valid file");
            if (_targetRuntime == null)
                throw new InvalidOperationException("A target runtime must be set before the container can be deployed");
        }
    }
}
