﻿/* ContainerItems.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.ObjectModel;
using System.IO;

namespace ZuneBoards.DevelopmentFront.DeployKit.Deployment
{
    sealed class ContainerItems : KeyedCollection<string, ContainerItem>
    {
        ContainerDirectory _owner;

        public ContainerItems() :
            this(null)
        {
        }
        public ContainerItems(ContainerDirectory owner) :
            base(StringComparer.InvariantCultureIgnoreCase)
        {
            _owner = owner;
        }
        protected override string GetKeyForItem(ContainerItem item)
        {
            return item.Name;
        }
        public void Import(string sourcePath)
        {
            foreach (string file in Directory.GetFiles(sourcePath))
            {
                ContainerFile cf = new ContainerFile(Path.GetFileName(file), file);
                Add(cf);
            }
            foreach (string dir in Directory.GetDirectories(sourcePath))
            {
                ContainerDirectory cd = new ContainerDirectory(Path.GetFileName(dir));
                cd.Items.Import(dir);
                Add(cd);
            }
        }
        protected override void InsertItem(int index, ContainerItem item)
        {
            base.InsertItem(index, item);
            item.Parent = _owner;
        }
        protected override void RemoveItem(int index)
        {
            ContainerItem olditem = this[index];
            base.RemoveItem(index);
            olditem.Parent = null;
        }
        public ContainerItem Resolve(string relativePath)
        {
            if (string.IsNullOrEmpty(relativePath))
                return _owner;
            string[] segments = relativePath.Split('\\');
            ContainerItems current = this;
            ContainerItem item = _owner;
            foreach (string segment in segments)
            {
                if (item is ContainerDirectory)
                    current = ((ContainerDirectory)item).Items;
                if (!current.Contains(segment))
                    return null;
                item = current[segment];
            }
            return item;
        }
        protected override void SetItem(int index, ContainerItem item)
        {
            ContainerItem olditem = this[index];
            base.SetItem(index, item);
            olditem.Parent = null;
            item.Parent = _owner;
        }
    }
}
