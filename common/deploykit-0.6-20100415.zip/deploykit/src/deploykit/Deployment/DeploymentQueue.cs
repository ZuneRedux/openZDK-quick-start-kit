﻿/* DeploymentQueue.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using ZuneBoards.DevelopmentFront.DeployKit.Engine;

namespace ZuneBoards.DevelopmentFront.DeployKit.Deployment
{
    sealed class DeploymentQueue
    {
        public event EventHandler<AsyncCompletedEventArgs> DeployCompleted;
        public event EventHandler<DeployProgressChangedEventArgs> DeployProgressChanged;
        Queue<Container> _containers;
        Endpoint _currentEndpoint;
        int _isBusy;

        public DeploymentQueue()
        {
            _containers = new Queue<Container>();
        }
        public bool IsBusy
        {
            get { return _isBusy != 0; }
        }
        void Container_DeployProgressChanged(object sender, DeployProgressChangedEventArgs e)
        {
            if (DeployProgressChanged != null)
                DeployProgressChanged(this, e);
        }
        void Container_DeployCompleted(object sender, AsyncCompletedEventArgs e)
        {
            // unhook events
            ((Container)sender).DeployProgressChanged -= Container_DeployProgressChanged;
            ((Container)sender).DeployCompleted -= Container_DeployCompleted;
            // determine what to do next
            if (e.Error != null || _containers.Count == 0)
            {
                _isBusy = 0;
                if (e.Error != null)
                    _containers.Clear();
                if (DeployCompleted != null)
                    DeployCompleted(this, e);
            }
            else
            {
                DeployNext(_currentEndpoint, e.UserState);
            }
        }
        public void Deploy(Endpoint endpoint)
        {
            if (Interlocked.Exchange(ref _isBusy, 1) != 0)
                throw new InvalidOperationException("The deployment queue is currently busy");
            try
            {
                while (_containers.Count > 0)
                    _containers.Dequeue().Deploy(endpoint);
            }
            catch
            {
                _isBusy = 0;
                _containers.Clear();
                throw;
            }
            _isBusy = 0;
        }
        public void DeployAsync(Endpoint endpoint)
        {
            DeployAsync(endpoint, null);
        }
        public void DeployAsync(Endpoint endpoint, object state)
        {
            if (Interlocked.Exchange(ref _isBusy, 1) != 0)
                throw new InvalidOperationException("The deployment queue is currently busy");
            if (_containers.Count != 0)
                DeployNext(endpoint, state);
            else
                _isBusy = 0;
        }
        void DeployNext(Endpoint endpoint, object state)
        {
            Container container = _containers.Dequeue();
            container.DeployProgressChanged += Container_DeployProgressChanged;
            container.DeployCompleted += Container_DeployCompleted;
            _currentEndpoint = endpoint;
            container.DeployAsync(endpoint, state);
        }
        public void Enqueue(Container container)
        {
            if (Interlocked.Exchange(ref _isBusy, 1) != 0)
                throw new InvalidOperationException("The deployment queue is currently busy");
            _containers.Enqueue(container);
            _isBusy = 0;
        }
    }
}
