﻿/* StatusWindow.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using ZuneBoards.DevelopmentFront.DeployKit.Deployment;
using ZuneBoards.DevelopmentFront.DeployKit.Engine;
using ZuneBoards.DevelopmentFront.DeployKit.Resources;

namespace ZuneBoards.DevelopmentFront.DeployKit
{
    partial class StatusWindow : Window
    {
        DeploymentQueue _queue;
        bool _forbidClose;

        public StatusWindow()
        {
            // initialize window
            this.InitializeComponent();
            // initialize deployment queue
            _queue = new DeploymentQueue();
            _queue.DeployProgressChanged += DeploymentQueue_DeployProgressChanged;
            _queue.DeployCompleted += DeploymentQueue_DeployCompleted;
            // update ui
            this.Title = App.Source.DisplayName;
            this.DisplayNameText.Text = App.Source.DisplayName;
            this.DescriptionText.Text = App.Source.Description;
            if (App.Source.ThumbnailPath != null)
            {
                Uri appbase = new Uri(Assembly.GetExecutingAssembly().Location);
                this.ThumbnailImage.Source = new BitmapImage(new Uri(appbase, App.Source.ThumbnailPath));
            }
            // populate targets
            IList<Endpoint> endpoints = Endpoint.GetEndpoints();
            this.TargetComboBox.ItemsSource = endpoints;
            if (endpoints.Count > 0)
            {
                int index = 0;
                for (int i = 0; i < endpoints.Count; ++i)
                {
                    if (endpoints[i].IsDefault)
                    {
                        index = i;
                        break;
                    }
                }
                this.TargetComboBox.SelectedIndex = index;
            }
            else
            {
                Inline part1 = new Run("No endpoints are available on which to install ");
                Inline part2 = new Bold(new Run(App.Source.DisplayName));
                Inline part3 = new Run(". Endpoints can be added using the ");
                Inline part4 = new Hyperlink(new Run("Device Center"));
                Inline part5 = new Run(".");
                ((Hyperlink)part4).Click += new RoutedEventHandler(DeviceCenterLink_Click);
                this.DeploymentIntroText.Inlines.Clear();
                this.DeploymentIntroText.Inlines.Add(part1);
                this.DeploymentIntroText.Inlines.Add(part2);
                this.DeploymentIntroText.Inlines.Add(part3);
                this.DeploymentIntroText.Inlines.Add(part4);
                this.DeploymentIntroText.Inlines.Add(part5);
            }
        }
        void DeployButton_Click(object sender, RoutedEventArgs e)
        {
            // switch up ui
            this.DeployButton.IsEnabled = false;
            this.TargetComboBox.IsEnabled = false;
            this.DeploymentIntroText.Visibility = Visibility.Collapsed;
            this.DeploymentStatusPanel.Visibility = Visibility.Visible;
            _forbidClose = true;
            // get deploying
            _queue.Enqueue(App.Source.TargetRuntime);
            _queue.Enqueue(App.Source);
            _queue.DeployAsync((Endpoint)TargetComboBox.SelectedItem);
        }
        void DeviceCenterLink_Click(object sender, RoutedEventArgs e)
        {
            // launch dc
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\XNA\Game Studio", false))
            {
                string path1 = key.GetValue("SharedComponentsPath") as string;
                string path2 = @"Device Center\XNADeviceCenter.exe";
                string fullpath;
                if (string.IsNullOrEmpty(path1) || !File.Exists(fullpath = Path.Combine(path1, path2)))
                    MessageBox.Show(Strings.DeviceCenterNotFoundMessage, Strings.DeviceCenterNotFoundCaption, MessageBoxButton.OK, MessageBoxImage.Warning);
                else
                    Process.Start(fullpath);
            }
            // exit so we don't have to auto-refresh
            Environment.Exit(0);
        }
        void RuntimeDownloadLink_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("http://www.microsoft.com/downloads/details.aspx?FamilyID=48f7ba37-8ba7-4d16-8873-0b7f83ef77f9");
        }        
        void DeploymentQueue_DeployCompleted(object sender, AsyncCompletedEventArgs e)
        {
            // switch up ui
            this.DeployButton.IsEnabled = true;
            this.TargetComboBox.IsEnabled = true;
            this.DeploymentStatusPanel.Visibility = Visibility.Collapsed;
            this.DeploymentIntroText.Visibility = Visibility.Visible;
            _forbidClose = false;
            // display error message if necessary
            if (e.Error != null)
            {
                // display error message text
                Inline part1 = new Run("The following error occured while attempting to install ");
                Inline part2 = new Bold(new Run(App.Source.DisplayName));
                Inline part3 = new Run(" on ");
                Inline part4 = new Bold(new Run(((Endpoint)TargetComboBox.SelectedItem).Name));
                Inline part5 = new Run(":\n\n[" + e.Error.GetType().Name + "]\n" + e.Error.Message);
                this.DeploymentIntroText.Inlines.Clear();
                this.DeploymentIntroText.Inlines.Add(part1);
                this.DeploymentIntroText.Inlines.Add(part2);
                this.DeploymentIntroText.Inlines.Add(part3);
                this.DeploymentIntroText.Inlines.Add(part4);
                this.DeploymentIntroText.Inlines.Add(part5);
            }
            else
            {
                // display success text
                Inline part1 = new Bold(new Run(App.Source.DisplayName));
                Inline part2 = new Run(" was successfully installed on ");
                Inline part3 = new Bold(new Run(((Endpoint)TargetComboBox.SelectedItem).Name));
                Inline part4 = new Run(".");
                this.DeploymentIntroText.Inlines.Clear();
                this.DeploymentIntroText.Inlines.Add(part1);
                this.DeploymentIntroText.Inlines.Add(part2);
                this.DeploymentIntroText.Inlines.Add(part3);
                this.DeploymentIntroText.Inlines.Add(part4);
            }
        }
        void DeploymentQueue_DeployProgressChanged(object sender, DeployProgressChangedEventArgs e)
        {
            switch (e.Task)
            {
                case DeploymentTask.VerifyingContainer:
                    if (e.Container is RuntimeContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.VerifyingContainerStatusFormat, ((RuntimeContainer)e.Container).RuntimeToken);
                    break;
                case DeploymentTask.StartDeployment:
                    if (e.Container is ApplicationContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.PreparingToDeployStatusFormat, ((ApplicationContainer)e.Container).DisplayName);
                    else if (e.Container is RuntimeContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.PreparingToDeployStatusFormat, ((RuntimeContainer)e.Container).RuntimeToken);
                    break;
                case DeploymentTask.DeployingFile:
                    this.DeploymentStatusText.Text = string.Format(Strings.DeployingFileStatusFormat, ((ContainerFile)e.Parameter).RelativePath);
                    break;
                case DeploymentTask.EndDeployment:
                    if (e.Container is ApplicationContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.FinishingDeploymentStatusFormat, ((ApplicationContainer)e.Container).DisplayName);
                    else if (e.Container is RuntimeContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.FinishingDeploymentStatusFormat, ((RuntimeContainer)e.Container).RuntimeToken);
                    break;
                case DeploymentTask.LaunchingApplication:
                    if (e.Container is ApplicationContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.LaunchingApplicationStatusFormat, ((ApplicationContainer)e.Container).StartupAssembly.RelativePath);
                    break;
                case DeploymentTask.WaitingForApplication:
                    if (e.Container is ApplicationContainer)
                        this.DeploymentStatusText.Text = string.Format(Strings.WaitingForApplicationStatusFormat, ((ApplicationContainer)e.Container).StartupAssembly.RelativePath);
                    break;
            }
        }
        void TargetComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // determine compatibility
            Endpoint endpoint = (Endpoint)TargetComboBox.SelectedItem;
            bool compatible;
            switch (App.Source.Compatibility)
            {
                case ApplicationCompatibility.HDOnly:
                    compatible = (endpoint.Type == EndpointType.Pavo);
                    break;
                case ApplicationCompatibility.SDOnly:
                    compatible = (endpoint.Type != EndpointType.Pavo);
                    break;
                case ApplicationCompatibility.Any:
                    compatible = true;
                    break;
                default:
                    compatible = false;
                    break;
            }
            // find target runtime
            string platform = (endpoint.Type == EndpointType.Pavo) ? "Zune4" : "Zune";
            IList<RuntimeContainer> runtimes = RuntimeContainer.GetInstalledRuntimes(platform);
            uint maxrev = 0;
            App.Source.TargetRuntime = null;
            foreach (RuntimeContainer rt in runtimes)
            {
                if (rt.Revision > maxrev)
                    App.Source.TargetRuntime = rt;
            }
            // update intro text
            if (App.Source.TargetRuntime == null)
            {
                Inline part1 = new Run("The XNA Framework runtime libraries required to deploy to ");
                Inline part2 = new Bold(new Run(endpoint.Name));
                Inline part3 = new Run(" are not available on this system. The latest libraries are available at the ");
                Inline part4 = new Hyperlink(new Run("Microsoft website"));
                Inline part5 = new Run(".");
                ((Hyperlink)part4).Click += new RoutedEventHandler(RuntimeDownloadLink_Click);
                this.DeploymentIntroText.Inlines.Clear();
                this.DeploymentIntroText.Inlines.Add(part1);
                this.DeploymentIntroText.Inlines.Add(part2);
                this.DeploymentIntroText.Inlines.Add(part3);
                this.DeploymentIntroText.Inlines.Add(part4);
                this.DeploymentIntroText.Inlines.Add(part5);
                DeployButton.IsEnabled = false;
            }
            else if (compatible)
            {
                Inline part1 = new Run("Click ");
                Inline part2 = new Bold(new Run("Deploy"));
                Inline part3 = new Run(" to install ");
                Inline part4 = new Bold(new Run(App.Source.DisplayName));
                Inline part5 = new Run(" on ");
                Inline part6 = new Bold(new Run(endpoint.Name));
                Inline part7 = new Run(".");
                this.DeploymentIntroText.Inlines.Clear();
                this.DeploymentIntroText.Inlines.Add(part1);
                this.DeploymentIntroText.Inlines.Add(part2);
                this.DeploymentIntroText.Inlines.Add(part3);
                this.DeploymentIntroText.Inlines.Add(part4);
                this.DeploymentIntroText.Inlines.Add(part5);
                this.DeploymentIntroText.Inlines.Add(part6);
                this.DeploymentIntroText.Inlines.Add(part7);
                DeployButton.IsEnabled = true;
            }
            else
            {
                Inline part1 = new Bold(new Run(App.Source.DisplayName));
                Inline part2 = new Run(" is not compatible with ");
                Inline part3 = new Bold(new Run(endpoint.Name));
                Inline part4 = new Run(". Select a different endpoint from the list above, or click ");
                Inline part5 = new Bold(new Run("Deploy"));
                Inline part6 = new Run(" to attempt to install anyway.");
                this.DeploymentIntroText.Inlines.Clear();
                this.DeploymentIntroText.Inlines.Add(part1);
                this.DeploymentIntroText.Inlines.Add(part2);
                this.DeploymentIntroText.Inlines.Add(part3);
                this.DeploymentIntroText.Inlines.Add(part4);
                this.DeploymentIntroText.Inlines.Add(part5);
                this.DeploymentIntroText.Inlines.Add(part6);
                DeployButton.IsEnabled = true;
            }
        }
        void Window_Closing(object sender, CancelEventArgs e)
        {
            e.Cancel = _forbidClose;
        }
    }
}
