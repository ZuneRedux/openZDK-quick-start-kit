﻿/* App.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using ZuneBoards.DevelopmentFront.DeployKit.Deployment;
using ZuneBoards.DevelopmentFront.DeployKit.Resources;

namespace ZuneBoards.DevelopmentFront.DeployKit
{
	partial class App : Application
	{
        static ApplicationContainer _source;

        public static ApplicationContainer Source
        {
            get { return _source; }
        }
        void App_Startup(object sender, StartupEventArgs e)
        {
            // check for xna availability
            try
            {
                Assembly.Load("Microsoft.Xna.GameStudio.DeviceManagement, Version=3.1.0.0, Culture=neutral, PublicKeyToken=6d5c3888ef60e27d");
                Assembly.Load("Microsoft.Xna.RemoteServices, Version=3.1.0.0, Culture=neutral, PublicKeyToken=6d5c3888ef60e27d");
            }
            catch
            {
                if (MessageBox.Show(Strings.XnaNotInstalledMessage, Strings.XnaNotInstalledCaption, MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes) == MessageBoxResult.Yes)
                    Process.Start("http://www.microsoft.com/downloads/details.aspx?FamilyID=80782277-d584-42d2-8024-893fcd9d3e82");
                Environment.Exit(1);
            }
            // load configuration
            try
            {
                string basedir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                _source = LoadApplicationContainer(Path.Combine(basedir, "application.cfg"));
            }
            catch (Exception ex)
            {
                string message = string.Format(Strings.InvalidConfigMessage, ex.GetType().Name, ex.Message);
                MessageBox.Show(message, Strings.InvalidConfigCaption, MessageBoxButton.OK, MessageBoxImage.Warning);
                Environment.Exit(1);
            }
        }
        static ApplicationContainer LoadApplicationContainer(string path)
        {
            // load data
            ApplicationContainer container = new ApplicationContainer();
            NameValueCollection data = Parse(path);
            string rawname = data["name"];
            string rawdescription = data["description"];
            string rawguid = data["guid"];
            string rawdisposition = data["disposition"];
            string rawlaunch = data["launch"];
            string rawthumbnail = data["thumbnail"];
            string rawsrc = data["src"];
            string rawexec = data["exec"];
            string rawcompatibility = data["compatibility"];
            // name
            if (string.IsNullOrEmpty(rawname))
                throw new InvalidDataException(Strings.DisplayNameRequired);
            container.DisplayName = rawname;
            // description
            container.Description = rawdescription;
            // guid
            if (string.IsNullOrEmpty(rawguid))
                throw new InvalidDataException(Strings.VirtualApplicationIdRequired);
            try
            {
                container.VirtualApplicationId = new Guid(rawguid);
            }
            catch
            {
                throw new InvalidDataException(Strings.VirtualApplicationIdInvalid);
            }
            // disposition
            switch (rawdisposition)
            {
                case "never":
                    container.DeploymentDisposition = DeploymentDisposition.Never;
                    break;
                case "automatic":
                    container.DeploymentDisposition = DeploymentDisposition.Auto;
                    break;
                case "always":
                case null:
                    container.DeploymentDisposition = DeploymentDisposition.Always;
                    break;
                default:
                    throw new InvalidDataException(Strings.DeploymentDispositionInvalid);
            }
            // launch
            switch (rawlaunch)
            {
                case "always":
                    container.LaunchDisposition = LaunchDisposition.NonBlocking;
                    break;
                case "wait":
                    container.LaunchDisposition = LaunchDisposition.Blocking;
                    break;
                case "never":
                case null:
                    container.LaunchDisposition = LaunchDisposition.None;
                    break;
                default:
                    throw new InvalidDataException(Strings.LaunchDispositionInvalid);
            }
            // thumbnail
            if (!string.IsNullOrEmpty(rawthumbnail) && !File.Exists(rawthumbnail))
                throw new InvalidDataException(Strings.ThumbnailImageMissing);
            container.ThumbnailPath = rawthumbnail;
            // src
            if (string.IsNullOrEmpty(rawsrc))
                throw new InvalidDataException(Strings.SourceDirectoryRequired);
            if (!Directory.Exists(rawsrc))
                throw new InvalidDataException(Strings.SourceDirectoryMissing);
            container.Contents.Import(rawsrc);
            // exec
            if (string.IsNullOrEmpty(rawexec))
                throw new InvalidDataException(Strings.StartupAssemblyRequired);
            container.StartupAssembly = container.Contents.Resolve(rawexec) as ContainerFile;
            if (container.StartupAssembly == null)
                throw new InvalidDataException(Strings.StartupAssemblyMissing);
            // compatibility
            switch (rawcompatibility)
            {
                case "hd":
                    container.Compatibility = ApplicationCompatibility.HDOnly;
                    break;
                case "sd":
                    container.Compatibility = ApplicationCompatibility.SDOnly;
                    break;
                case "any":
                case null:
                    container.Compatibility = ApplicationCompatibility.Any;
                    break;
                default:
                    throw new InvalidDataException(Strings.CompatibilityInvalid);
            }
            // done
            return container;
        }
        static NameValueCollection Parse(string path)
        {
            NameValueCollection nvc = new NameValueCollection();
            using (StreamReader sr = new StreamReader(path))
            {
                string line;
                int lineNo = 0;
                while ((line = sr.ReadLine()) != null)
                {
                    ++lineNo;
                    if (line.StartsWith("#"))
                        continue;
                    if (line.Trim().Length == 0)
                        continue;
                    string[] segments = line.Split(':');
                    if (segments.Length != 2)
                        throw new InvalidDataException(string.Format(Strings.InvalidKeyValueFormat, lineNo.ToString()));
                    string key = segments[0].Trim();
                    string value = segments[1].Trim();
                    if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
                        throw new InvalidDataException(string.Format(Strings.InvalidKeyValueFormat, lineNo.ToString()));
                    nvc[key] = value;
                }
            }
            return nvc;
        }
	}
}