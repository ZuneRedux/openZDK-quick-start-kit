﻿using System.IO;
using System.Reflection;
using System.Windows;

namespace ZuneBoards.DevelopmentFront.ExploitDeploymentTool
{
    public partial class EulaWindow : Window
    {
        const string _resourceName = "ZuneBoards.DevelopmentFront.ExploitDeploymentTool.Resources.Eula.rtf";

        public EulaWindow()
        {
            InitializeComponent();
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(_resourceName))
            {
                EulaText.Selection.Load(stream, DataFormats.Rtf);
            }
        }
        void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
        void DeclineButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
