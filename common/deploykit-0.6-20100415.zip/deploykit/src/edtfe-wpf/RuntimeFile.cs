﻿/* RuntimeFile.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Windows;

namespace ZuneBoards.DevelopmentFront.ExploitDeploymentTool
{
    sealed class RuntimeFile : DependencyObject
    {
        public static DependencyProperty StatusProperty = DependencyProperty.Register("Status", typeof(DeploymentStatus), typeof(RuntimeFile), new PropertyMetadata(DeploymentStatus.Ready));
        string _sourcePath;
        string _targetPath;

        public RuntimeFile(string sourcePath, string targetPath)
        {
            if (string.IsNullOrEmpty(sourcePath))
                throw new ArgumentException("A source path must be specified", "sourcePath");
            if (string.IsNullOrEmpty(targetPath))
                throw new ArgumentException("A target path must be specified", "targetPath");
            _sourcePath = sourcePath;
            _targetPath = targetPath;
        }
        public string SourcePath
        {
            get { return _sourcePath; }
        }
        public string TargetPath
        {
            get { return _targetPath; }
        }
        public DeploymentStatus Status
        {
            get { return (DeploymentStatus)this.GetValue(StatusProperty); }
            set { this.SetValue(StatusProperty, value); }
        }
    }
}
