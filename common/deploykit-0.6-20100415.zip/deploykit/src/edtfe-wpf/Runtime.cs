﻿/* Runtime.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using Microsoft.Win32;
using ZuneBoards.DevelopmentFront.DeployKit.Engine;

namespace ZuneBoards.DevelopmentFront.ExploitDeploymentTool
{
    sealed class Runtime
    {
        struct DeploymentState
        {
            public readonly Runtime Runtime;
            public readonly Endpoint Device;
            public readonly object State;
            readonly AsyncOperation _asyncOperation;

            DeploymentState(Runtime runtime, Endpoint device)
            {
                if (runtime == null)
                    throw new ArgumentNullException("runtime");
                if (device == null)
                    throw new ArgumentNullException("device");
                Runtime = runtime;
                Device = device;
                State = null;
                _asyncOperation = null;
            }
            DeploymentState(Runtime runtime, Endpoint device, object state)
            {
                if (runtime == null)
                    throw new ArgumentNullException("runtime");
                if (device == null)
                    throw new ArgumentNullException("device");
                Runtime = runtime;
                Device = device;
                State = state;
                _asyncOperation = AsyncOperationManager.CreateOperation(state);
            }
            public static DeploymentState CreateSync(Runtime runtime, Endpoint device)
            {
                return new DeploymentState(runtime, device, null);
            }
            public static DeploymentState CreateAsync(Runtime runtime, Endpoint device, object state)
            {
                return new DeploymentState(runtime, device, state);                
            }
            public void ProgressChanged(RuntimeFile file, DeploymentStatus status)
            {
                if (_asyncOperation != null)
                    _asyncOperation.Post(SendProgressChanged, new DeployProgressChangedEventArgs(file, status, State));
            }
            public void Faulted(Exception ex)
            {
                if (_asyncOperation != null)
                    _asyncOperation.PostOperationCompleted(SendDeployCompleted, new AsyncCompletedEventArgs(ex, false, State));
                else
                    throw ex;
            }
            public void Completed()
            {
                if (_asyncOperation != null)
                    _asyncOperation.PostOperationCompleted(SendDeployCompleted, new AsyncCompletedEventArgs(null, false, State));
            }
            void SendProgressChanged(object state)
            {
                if (Runtime.DeployProgressChanged != null)
                    Runtime.DeployProgressChanged(Runtime, state as DeployProgressChangedEventArgs);
            }
            void SendDeployCompleted(object state)
            {
                if (Runtime.DeployCompleted != null)
                    Runtime.DeployCompleted(Runtime, state as AsyncCompletedEventArgs);
            }
        }

        public event EventHandler<AsyncCompletedEventArgs> DeployCompleted;
        public event EventHandler<DeployProgressChangedEventArgs> DeployProgressChanged;

        RuntimeFileCollection _files = new RuntimeFileCollection();
        string _runtimeToken;
        string _label;
        uint _version;

        public Runtime(string runtimeToken, string label, uint version)
        {
            if (string.IsNullOrEmpty(runtimeToken))
                throw new ArgumentException("A runtime token must be specified", "runtimeToken");
            _runtimeToken = runtimeToken;
            _label = label;
            _version = version;
        }
        public RuntimeFileCollection Files
        {
            get { return _files; }
        }
        public string RuntimeToken
        {
            get { return _runtimeToken; }
        }
        public string Label
        {
            get { return _label; }
        }
        public uint Version
        {
            get { return _version; }
        }
        public static IList<Runtime> GetInstalledRuntimes(string platform)
        {
            if (string.IsNullOrEmpty(platform))
                throw new ArgumentException("A platform must be specified", "platform");
            List<Runtime> runtimes = new List<Runtime>();
            RegistryKey root = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\XNA\Game Studio\DeployableRuntimes\" + platform);
            if (root == null)
                return runtimes;
            using (root)
            {
                string[] tokens = root.GetSubKeyNames();
                foreach (string token in tokens)
                {
                    using (RegistryKey tokenKey = root.OpenSubKey(token))
                    {
                        string[] labels = tokenKey.GetSubKeyNames();
                        foreach (string label in labels)
                        {
                            using (RegistryKey labelKey = tokenKey.OpenSubKey(label))
                            {
                                uint? version = (uint?)(labelKey.GetValue("Version") as int?);
                                string sourceDir = labelKey.GetValue("Path") as string;
                                if (version == null || string.IsNullOrEmpty(sourceDir))
                                    continue;
                                Runtime rt = new Runtime(token == "Zune.v3.1" ? "Zune.v4.0.Beta" : token, label, version.Value);
                                // HACK: considers 1st level files only
                                foreach (string sourcePath in Directory.GetFiles(sourceDir))
                                    rt.Files.Add(new RuntimeFile(sourcePath, Path.GetFileName(sourcePath)));
                                runtimes.Add(rt);
                            }
                        }
                    }
                }
            }
            return runtimes;
        }
        public void Deploy(Endpoint device)
        {
            DeployInternal(DeploymentState.CreateSync(this, device));
        }
        public void DeployAsync(Endpoint device)
        {
            DeployAsync(device, null);
        }
        public void DeployAsync(Endpoint device, object state)
        {
            ThreadPool.UnsafeQueueUserWorkItem(s => DeployInternal((DeploymentState)s), DeploymentState.CreateAsync(this, device, state));
        }
        static void DeployInternal(DeploymentState status)
        {
            try
            {
                foreach (RuntimeFile file in status.Runtime.Files)
                    status.ProgressChanged(file, DeploymentStatus.Queued);
                using (Channel channel = new Channel(status.Device, Channel.RuntimeDeploymentChannelType))
                {
                    channel.Actions["OpenRuntimeContainer"].Invoke(status.Runtime.RuntimeToken, status.Runtime.Version);
                    try
                    {
                        foreach (RuntimeFile file in status.Runtime.Files)
                        {
                            try
                            {
                                status.ProgressChanged(file, DeploymentStatus.Deploying);
                                using (FileStream fs = new FileStream(file.SourcePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                                {
                                    channel.Actions["PutFileInContainer"].Invoke(file.TargetPath, fs);
                                }
                                status.ProgressChanged(file, DeploymentStatus.Deployed);
                            }
                            catch
                            {
                                status.ProgressChanged(file, DeploymentStatus.Failed);
                                throw;
                            }
                        }
                    }
                    finally
                    {
                        channel.Actions["CloseRuntimeContainer"].Invoke();
                    }
                }
                status.Completed();
            }
            catch (Exception ex)
            {
                status.Faulted(ex);
            }
        }
        public override string ToString()
        {
            return string.Format("{0} ({1})", Label ?? "0x" + Version.ToString("x8"), RuntimeToken);
        }
    }
}
