﻿/* StatusWindow.cs
 * Copyright (c) 2010 itsnotabigtruck.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using ZuneBoards.DevelopmentFront.DeployKit.Engine;
using Path = System.IO.Path;

namespace ZuneBoards.DevelopmentFront.ExploitDeploymentTool
{
	partial class StatusWindow : Window
	{
        string _sourceDir;
        bool _deploying;

		public StatusWindow()
		{
			this.InitializeComponent();
            // determine .net cf source directory
            string[] clargs = Environment.GetCommandLineArgs();
            if (clargs.Length > 1 && !string.IsNullOrEmpty(clargs[1]) && Directory.Exists(clargs[1]))
            {
                _sourceDir = clargs[1];
            }
            else
            {
                HackRadioButton.IsChecked = HackRadioButton.IsEnabled = false;
                UnhackRadioButton.IsChecked = true;
            }
            // populate target list
            TargetComboBox.ItemsSource = Endpoint.GetEndpoints();
            if (TargetComboBox.Items.Count > 0)
                TargetComboBox.SelectedIndex = 0;
		}
        void TargetComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Endpoint target = TargetComboBox.SelectedItem as Endpoint;
            if (target != null)
            {
                string targetType = target.Type == EndpointType.Pavo ? "Zune4" : "Zune";
                RuntimeComboBox.ItemsSource = Runtime.GetInstalledRuntimes(targetType);
                if (RuntimeComboBox.Items.Count > 0)
                    RuntimeComboBox.SelectedIndex = RuntimeComboBox.Items.Count - 1;
            }
        }
        void RuntimeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Runtime rt = (Runtime)RuntimeComboBox.SelectedItem;
            if (rt != null)
                FileStatusListView.ItemsSource = rt.Files;
            else
                FileStatusListView.ItemsSource = null;
        }
        void DeployButton_Click(object sender, RoutedEventArgs e)
        {
            // collect working data
            Runtime runtime = RuntimeComboBox.SelectedItem as Runtime;
            Endpoint target = TargetComboBox.SelectedItem as Endpoint;
            if (runtime == null || target == null) return;
            // update ui
            DeployButton.IsEnabled = false;
            TargetComboBox.IsEnabled = false;
            RuntimeComboBox.IsEnabled = false;
            HackRadioButton.IsEnabled = false;
            UnhackRadioButton.IsEnabled = false;
            // replace runtime with hacked version if necessary
            if (HackRadioButton.IsChecked == true)
                runtime = MakeHackedRuntime(runtime, _sourceDir);
            FileStatusListView.ItemsSource = runtime.Files;
            // set flag
            _deploying = true;
            // start deployment
            runtime.DeployCompleted += Runtime_DeployCompleted;
            runtime.DeployProgressChanged += Runtime_DeployProgressChanged;
            runtime.DeployAsync(target);
        }
        void Runtime_DeployCompleted(object sender, AsyncCompletedEventArgs e)
        {
            Runtime runtime = (Runtime)sender;
            // unset flag
            _deploying = false;
            // unhook events
            runtime.DeployCompleted -= Runtime_DeployCompleted;
            runtime.DeployProgressChanged -= Runtime_DeployProgressChanged;
            // update ui
            DeployButton.IsEnabled = true;
            TargetComboBox.IsEnabled = true;
            RuntimeComboBox.IsEnabled = true;
            HackRadioButton.IsEnabled = _sourceDir != null;
            UnhackRadioButton.IsEnabled = true;
            // display error message
            if (e.Error != null)
            {
                string message = string.Format("The following error occurred while attempting to deploy the runtime.\n\n[{0}]\n{1}", e.Error.GetType().Name, e.Error.Message);
                MessageBox.Show(message, "Deployment Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        void Runtime_DeployProgressChanged(object sender, DeployProgressChangedEventArgs e)
        {
            e.File.Status = e.Status;
        }
        void StatusWindow_Closing(object sender, CancelEventArgs e)
        {
            e.Cancel = _deploying;
        }
        void StatusWindow_Loaded(object sender, EventArgs e)
        {
            EulaWindow eula = new EulaWindow();
            if (eula.ShowDialog() != true)
                Close();
        }
        static Runtime MakeHackedRuntime(Runtime runtime, string sourceDir)
        {
            Runtime hacked = new Runtime(runtime.RuntimeToken, runtime.Label, runtime.Version);
            foreach (RuntimeFile file in runtime.Files)
                hacked.Files.Add(file);
            foreach (string sourceFile in Directory.GetFiles(sourceDir))
            {
                string targetPath = Path.GetFileName(sourceFile);
                if (hacked.Files.Contains(targetPath.ToLowerInvariant()))
                {
                    int idx = hacked.Files.IndexOf(hacked.Files[targetPath.ToLowerInvariant()]);
                    hacked.Files.RemoveAt(idx);
                    hacked.Files.Insert(idx, new RuntimeFile(sourceFile, targetPath));
                }
                else
                {
                    hacked.Files.Add(new RuntimeFile(sourceFile, targetPath));
                }
            }
            return hacked;
        }
	}
}